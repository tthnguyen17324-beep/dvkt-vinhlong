import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, createVerify } from 'node:crypto';
import * as gs from '../server/gsheets.mjs';

const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
const env = {
  GOOGLE_SERVICE_ACCOUNT_JSON: JSON.stringify({ client_email: 'bot@proj.iam.gserviceaccount.com', private_key: pem }),
  GOOGLE_DRIVE_FOLDER_ID: 'FOLDER123',
  GOOGLE_SHEET_SHARE: 'anyone',
};

test('tắt khi thiếu cấu hình', () => {
  assert.equal(gs.isEnabled({}), false);
  assert.equal(gs.isEnabled({ GOOGLE_DRIVE_FOLDER_ID: 'x' }), false);
  assert.equal(gs.isEnabled(env), true);
});

test('JWT ký đúng RS256', () => {
  const jwt = gs.signJwt(JSON.parse(env.GOOGLE_SERVICE_ACCOUNT_JSON), 1000);
  const [h, b, s] = jwt.split('.');
  assert.equal(JSON.parse(Buffer.from(h, 'base64url')).alg, 'RS256');
  const claims = JSON.parse(Buffer.from(b, 'base64url'));
  assert.equal(claims.iss, 'bot@proj.iam.gserviceaccount.com');
  assert.equal(claims.exp, 4600);
  assert.ok(createVerify('RSA-SHA256').update(`${h}.${b}`).verify(publicKey, Buffer.from(s, 'base64url')));
});

test('tải .xlsx lên Drive dạng Google Sheet và chia sẻ', async () => {
  const calls = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, opt) => {
    calls.push({ url: String(url), opt });
    if (String(url).includes('oauth2')) return new Response(JSON.stringify({ access_token: 'TOKEN', expires_in: 3600 }), { status: 200 });
    if (String(url).includes('/upload/drive')) return new Response(JSON.stringify({ id: 'SHEET1', webViewLink: 'https://docs.google.com/spreadsheets/d/SHEET1/edit' }), { status: 200 });
    return new Response('{}', { status: 200 });
  };
  try {
    const url = await gs.uploadAsSheet('BaoCao', Buffer.from('PKfake'), env);
    assert.equal(url, 'https://docs.google.com/spreadsheets/d/SHEET1/edit');
    const up = calls.find((c) => c.url.includes('/upload/drive'));
    assert.equal(up.opt.headers.authorization, 'Bearer TOKEN');
    const body = up.opt.body.toString();
    assert.match(body, /"mimeType":"application\/vnd.google-apps.spreadsheet"/);
    assert.match(body, /"parents":\["FOLDER123"\]/);
    assert.ok(calls.some((c) => c.url.includes('/permissions') && JSON.parse(c.opt.body).type === 'anyone'));
  } finally { globalThis.fetch = realFetch; }
});
