// Kiểm thử luồng chính trên bản sao CSDL (không làm thay đổi dữ liệu thật).
import test from 'node:test';
import assert from 'node:assert/strict';
import { copyFileSync, mkdtempSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildApp } from '../server/app.mjs';
import { cleanKey } from '../server/logic.mjs';

const SRC = join(process.env.DATA_DIR || 'data', 'dvkt.db');
const ADMIN = 'admin-test';
const TOKEN = 'tok-12345';

test('luồng đầy đủ: xác thực → chọn → lưu → nộp → tra cứu → xuất → mở khóa', { skip: !existsSync(SRC) }, async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'dvkt-'));
  process.env.DATA_DIR = dir;
  copyFileSync(SRC, join(dir, 'dvkt.db'));
  const app = await buildApp({ dbPath: join(dir, 'dvkt.db'), adminPassword: ADMIN });
  t.after(() => app.close());
  const j = async (method, url, { body, auth, admin } = {}) => {
    const headers = {};
    if (auth) { headers['x-unit'] = auth.ma; headers['x-token'] = auth.token; }
    if (admin) headers['x-admin'] = ADMIN;
    const r = await app.inject({ method, url, headers, payload: body });
    return { status: r.statusCode, json: () => r.json(), raw: r };
  };

  const all = (await j('GET', '/api/lookup-hospitals')).json().hospitals;
  assert.ok(all.length > 100, 'danh sách đơn vị tra cứu');
  // Dữ liệu thật: hầu hết đơn vị đang "Đã khóa" -> mở khóa một đơn vị để thử luồng nhập liệu.
  const unit = all.find((h) => h.ma.startsWith('BV'));
  assert.equal((await j('POST', '/api/admin/unlock', { body: { password: ADMIN, ma: unit.ma } })).json().success, true);
  assert.ok((await j('GET', '/api/hospitals')).json().hospitals.some((h) => h.ma === unit.ma), 'đơn vị đã mở khóa xuất hiện trong danh sách');
  const auth = { ma: unit.ma, token: TOKEN };

  assert.equal((await j('POST', '/api/verify', { body: { ma: unit.ma, token: 'sai' } })).json().isValid, false);
  assert.equal((await j('POST', '/api/admin/unit', { body: { password: ADMIN, ma: unit.ma, token: TOKEN } })).json().success, true);
  assert.equal((await j('POST', '/api/verify', { body: auth })).json().isValid, true);

  // Danh mục
  const pl1 = (await j('GET', '/api/catalog/pl1?lh=H2')).json().data;
  assert.ok(pl1[0].isHeader && pl1.find((i) => i.ten === 'Khám bệnh'));
  const pl2 = (await j('GET', '/api/catalog/pl2?lh=H2')).json().data;
  assert.ok(pl2.length > 5);
  const chapters = (await j('GET', '/api/catalog/pl3/chapters?tyt=0')).json();
  assert.ok(chapters.length > 10);
  const ch = (await j('GET', `/api/catalog/pl3/chapter?tyt=0&name=${encodeURIComponent(chapters[0].name)}`)).json().data;
  assert.equal(ch.length, chapters[0].count);
  const pl4 = (await j('GET', '/api/catalog/pl4')).json().data;
  const pl5 = (await j('GET', '/api/catalog/pl5')).json().data;
  assert.ok(pl4.length > 100 && pl5.length > 100);

  // Chọn dịch vụ
  const k = (a, b) => { const c = cleanKey(a), d = cleanKey(b); return c ? `${c}_${d}` : d; };
  await j('PUT', '/api/meta', { auth, body: { loaiHinh: 'H2', hoTen: 'Nguyễn Văn A', khoaPhong: 'KHTH', chucVu: 'Trưởng phòng', soDienThoai: '0900000000', emailThaoTac: 'a@b.vn' } });
  const sel = async (pl, items) => assert.equal((await j('PUT', '/api/selections', { auth, body: { pl, items } })).json().success, true);
  await sel('pl1', [{ key: cleanKey('Khám bệnh'), tichChon: true, ghiChu: 'ghi chú KB' }]);
  const p2 = pl2.find((i) => i.hasAction);
  await sel('pl2', [{ key: cleanKey(p2.ten), tichChon: true }]);
  await sel('pl3', ch.slice(0, 3).map((i) => ({ key: k(i.maDungChung, i.maKyThuat), tichChon: true, ghiChu: 'x' })));
  await sel('pl4', pl4.slice(0, 2).map((i) => ({ key: k(i.rowValues[1], i.rowValues[3]), tichChon: true })));
  await sel('pl5', pl5.slice(0, 2).map((i) => ({ key: k(i.rowValues[1], i.rowValues[3]), tichChon: true })));

  const st = (await j('GET', '/api/state', { auth })).json();
  assert.equal(Object.keys(st.selections.pl3).length, 3);
  assert.equal(st.selections.pl1[cleanKey('Khám bệnh')].ghiChu, 'ghi chú KB');
  assert.equal((await j('GET', `/api/state?since=${st.version}`, { auth })).json().unchanged, true);
  assert.equal((await j('GET', '/api/state', { auth: { ma: unit.ma, token: 'sai' } })).json().success, false);

  // Nộp khi thiếu hồ sơ -> bị từ chối
  const miss = (await j('POST', '/api/save', { auth, body: { isFinalSubmit: true } })).json();
  assert.equal(miss.success, false);
  assert.match(miss.message, /Quyết định/);

  // Tải tệp
  const upload = async (label, name, content, mime = 'application/pdf') => {
    const b = '----t' + Date.now();
    const body = Buffer.concat([
      Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="typeLabel"\r\n\r\n${label}\r\n`),
      Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="${name}"\r\nContent-Type: ${mime}\r\n\r\n`),
      Buffer.from(content), Buffer.from(`\r\n--${b}--\r\n`),
    ]);
    const r = await app.inject({ method: 'POST', url: '/api/files', headers: { 'x-unit': auth.ma, 'x-token': auth.token, 'content-type': `multipart/form-data; boundary=${b}` }, payload: body });
    return r.json();
  };
  assert.equal((await upload('QD_XepHangBV_hoac_QD_ThanhlapTYT', 'x.pdf', 'khong phai pdf')).success, false, 'từ chối PDF giả');
  assert.equal((await upload('HoSo_MinhChungKhac', 'virus.exe', 'MZ', 'application/octet-stream')).success, false, 'từ chối .exe');
  assert.equal((await upload('QD_XepHangBV_hoac_QD_ThanhlapTYT', 'xep-hang.pdf', '%PDF-1.4 test')).success, true);
  assert.equal((await upload('QD_PheDuyetDVKT', 'phe-duyet.pdf', '%PDF-1.4 test')).success, true);

  // Nộp chính thức
  const fin = (await j('POST', '/api/save', { auth, body: { isFinalSubmit: true } })).json();
  assert.equal(fin.success, true, fin.message);
  assert.ok(!(await j('GET', '/api/hospitals')).json().hospitals.some((h) => h.ma === unit.ma), 'đơn vị bị khóa khỏi danh sách');
  assert.equal((await j('PUT', '/api/selections', { auth, body: { pl: 'pl1', items: [] } })).json().success, false, 'đã khóa thì không sửa được');

  // Tra cứu
  const lk = (await j('GET', '/api/lookup', { auth })).json();
  assert.equal(lk.isLocked, true);
  assert.equal(lk.counts.c3, 3); assert.equal(lk.counts.c4, 2); assert.equal(lk.counts.c5, 2); assert.equal(lk.counts.totalKT, 7);
  assert.equal(lk.counts.pl1_kb, 'X');
  assert.equal(lk.attachedFiles.length, 2);

  // Xuất Excel
  const x = await j('GET', `/api/export?id=${lk.submissionId}`, { auth });
  assert.equal(x.status, 200);
  assert.ok(x.raw.rawPayload.length > 5000 && x.raw.rawPayload.subarray(0, 2).toString() === 'PK');
  const ExcelJS = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook(); await wb.xlsx.load(x.raw.rawPayload);
  assert.deepEqual(wb.worksheets.map((w) => w.name), ['PL1', 'PL2', 'PL3', 'PL4', 'PL5']);
  const w3 = wb.getWorksheet('PL3');
  assert.equal(w3.getRow(5).getCell(2).value, 'Mã DVKT dùng chung\n\n(2)');
  assert.equal(w3.rowCount - 5, 3);
  assert.match(String(w3.getRow(6).getCell(2).value), /^\d\d\.\d{4}\.\d{4}$/, 'mã DVKT giữ nguyên dạng chuỗi');

  // Admin
  assert.equal((await j('POST', '/api/admin/summary', { body: { password: 'sai' } })).json().success, false);
  const sum = (await j('POST', '/api/admin/summary', { body: { password: ADMIN } })).json();
  assert.ok(sum.list.some((r) => r.ma === unit.ma && r.totalKT === 7));
  assert.equal((await j('GET', `/api/admin/export/${lk.submissionId}`, {})).status, 401);
  assert.equal((await j('GET', `/api/admin/export/${lk.submissionId}`, { admin: true })).status, 200);

  // Mở khóa → khôi phục phiên cũ
  assert.equal((await j('POST', '/api/admin/unlock', { body: { password: ADMIN, ma: unit.ma } })).json().success, true);
  assert.ok((await j('GET', '/api/hospitals')).json().hospitals.some((h) => h.ma === unit.ma));
  await sel('pl3', [{ key: k(ch[0].maDungChung, ch[0].maKyThuat), tichChon: false }]);
  const rs = (await j('POST', '/api/restore', { auth, body: { id: lk.submissionId } })).json();
  assert.equal(rs.success, true);
  assert.equal(rs.counts.c3, 3);
  assert.equal((await j('GET', '/api/state', { auth })).json().selections.pl3[k(ch[0].maDungChung, ch[0].maKyThuat)].tichChon, true);
});
