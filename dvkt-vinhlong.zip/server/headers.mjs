// Tiêu đề cột các phụ lục - giữ NGUYÊN VĂN như bản Apps Script (3_SaveSubmit.gs).
export function getPL1HeaderRow() {
  return [
    "STT\n\n(1)", "Danh mục dịch vụ\n\n(2)", "Chi phí trực tiếp\n\n(3)", "Tiền lương cơ sở 1.800.000 đồng\n\n(4)", "Tiền lương cơ sở 2.340.000 đồng\n\n(5)=(4)*2,34/1,8",
    "Giá bao gồm chi phí trực tiếp và tiền lương cơ sở 1.800.000 đồng (Thông tư số 22/2023/TT-BYT)\n\n(6)=(3)+(4)", "Giá bao gồm chi phí trực tiếp, tiền lương cơ sở 2.340.000 đồng (chưa làm tròn)\n\n(7)=(3)+(5)", " Chi phí quản lý (4%) (lương cơ sở 2.340.000 đồng)\n\n(8)=(7)*4%",
    "Giá bao gồm chi phí trực tiếp, tiền lương cơ sở 2.340.000 đồng và chi phí quản lý 4%(chưa làm tròn)\n\n(9)=(7)+(8)", "Giá đề nghị phê duyệt (làm tròn số học) (lương cơ sở 2.340.000 đồng)\n\n(10)", "Mức giá do quỹ BHYT thanh toán\n\n(11)",
    "Mức giá không thuộc quỹ BHYT thanh toán\n\n(12)", "Ghi chú của đơn vị\n\n(13)"
  ];
}

export function getPL2HeaderRow() {
  return [
    "STT\n\n(1)", "Các loại dịch vụ\n\n(2)", "Chi phí trực tiếp\n\n(3)", "Phụ cấp\n\n(4)", "Lương cơ sở 1.800.000 đồng\n\n(5)", "Lương cơ sở 2.340.000 đồng\n\n(6)=(5)*2,34/1,8",
    "Giá tại Thông tư số 21/2023/TT-BYT và Thông tư số 22/2023/TT-BYT (Chi phí trực tiếp + lương 1.800.000 đồng)\n\n(7)=(3)+(4)+(5)", "Tổng 2 yếu tố  (Chi phí trực tiếp + lương 2.340.000 đồng)\n\n(8)=(3)+(4)+(6)", "Chi phí quản lý 4% (lương cơ sở 2.340.000 đồng)\n\n(9)=(8)*4%", "Tổng 3 yếu tố  (Chi phí trực tiếp + lương 2.340.000 đồng) và Chi phí quản lý 4% (chưa làm tròn)\n\n(10)=(8)+(9)",
    "Giá đề nghị phê duyệt (làm tròn)\n\n(11)", "Mức giá do quỹ BHYT thanh toán\n\n(12)", "Mức giá không thuộc quỹ BHYT thanh toán\n\n(13)",
    "Ghi chú của đơn vị\n\n(14)"
  ];
}

export function getPL3HeaderRow(isTYT) {
  if (isTYT) {
    return [
      "STT\n\n(1)", "Mã DVKT dùng chung\n\n(2)", "Tên chương theo Thông tư số 23/2024/TT-BYT\n\n(3)", "Mã kỹ thuật theo Thông tư số 23/2024/TT-BYT\n\n(4)", "Tên dịch vụ kỹ thuật theo Thông tư 23/2024/TT-BYT\n\n(5)",
      "Tên dịch vụ phê duyệt giá\n\n(6)", "Chi phí trực tiếp + Phụ cấp\n\n(7)", "Lương cơ sở 1.800.000 đồng\n\n(8)", "Tiền lương cơ sở 2.340.000 đồng\n\n(9)=(8)*2,34/1,8",
      "Giá bao gồm chi phí trực tiếp, tiền lương tại Thông tư số 21/2023/TT-BYT và Thông tư số 22/2023/TT-BYT\n\n(10)=(7)+(8)", "Giá bao gồm chi phí trực tiếp, phụ cấp và tiền lương cơ sở 2.340.000 đồng\n\n(11)=(7)+(9)", "Chi phí quản lý (4%) (lương cơ sở 2.340.000 đồng)\n\n(12)=11*4%",
      "Giá bao gồm chi phí trực tiếp, phụ cấp, tiền lương cơ sở 2.340.000 đồng và chi phí quản lý 4% (chưa làm tròn)\n\n(13)=(11)+(12)", "[Giá bao gồm chi phí trực tiếp, phụ cấp, tiền lương cơ sở 2.340.000 đồng và chi phí quản lý 4%]*70% (chưa làm tròn)\n\n(14)", "Giá đề nghị phê duyệt (làm tròn )\n\n(15)",
      "Mức giá do quỹ BHYT thanh toán\n\n(16)", "Mức giá không thuộc quỹ BHYT thanh toán\n\n(17)", "Ghi chú gốc\n\n(18)", "Ghi chú của đơn vị\n\n(19)"
    ];
  }
  return [
    "STT\n\n(1)", "Mã DVKT dùng chung\n\n(2)", "Tên chương theo Thông tư số 23/2024/TT-BYT\n\n(3)", "Mã kỹ thuật theo Thông tư số 23/2024/TT-BYT\n\n(4)", "Tên dịch vụ kỹ thuật theo Thông tư 23/2024/TT-BYT\n\n(5)",
    "Tên dịch vụ phê duyệt giá\n\n(6)", "Chi phí trực tiếp + Phụ cấp\n\n(7)", "Lương cơ sở 1.800.000 đồng\n\n(8)", "Tiền lương cơ sở 2.340.000 đồng\n\n(9)=(8)*2,34/1,8",
    "Giá bao gồm chi phí trực tiếp, tiền lương tại Thông tư số 21/2023/TT-BYT và Thông tư số 22/2023/TT-BYT\n\n(10)=(7)+(8)", "Giá bao gồm chi phí trực tiếp, phụ cấp và tiền lương cơ sở 2.340.000 đồng\n\n(11)=(7)+(9)", "Chi phí quản lý (4%) (lương cơ sở 2.340.000 đồng)\n\n(12)=(11)*4%",
    "Giá bao gồm chi phí trực tiếp, phụ cấp, tiền lương cơ sở 2.340.000 đồng và chi phí quản lý 4% (chưa làm tròn)\n\n(13)=(11)+(12)", "Giá đề nghị phê duyệt (làm tròn)\n\n(14)", "Mức giá do quỹ BHYT thanh toán\n\n(15)",
    "Mức giá không thuộc quỹ BHYT thanh toán\n\n(16)", "Ghi chú gốc\n\n(17)", "Ghi chú của đơn vị\n\n(18)"
  ];
}

export function getPL4HeaderRow() {
  return [
    "STT\n\n(1)", "Mã DVKT dùng chung\n\n(2)", "Tên chương theo Thông tư số 23/2024/TT-BYT\n\n(3)", "Mã kỹ thuật theo Thông tư số 23/2024/TT-BYT\n\n(4)", "Tên kỹ thuật theo Thông tư số 23/2024/TT-BYT\n\n(5)",
    "Tên dịch vụ phê duyệt giá\n\n(6)", "Chi phí trực tiếp + phụ cấp\n\n(7)", "Tiền lương cơ sở 1.800.000 đồng (chưa làm tròn)\n\n(8)", "Tiền lương cơ sở 2.340.000 đồng (chưa làm tròn)\n\n(9)=(8)*2,34/1,8",
    "Giá bao gồm chi phí trực tiếp và tiền lương theo mức lương cơ sở 1.800.000 đồng (làm tròn)\n\n(10)=(7)+(8)", "Giá bao gồm chi phí trực tiếp, phụ cấp và tiền lương cơ sở 2.340.000 đồng (chưa làm tròn)\n\n(11)=(7)+(9)", "Chi phí quản lý (4%) (lương cơ sở 2.340.000 đồng)\n\n(12)=(11)*4%",
    "Giá bao gồm chi phí trực tiếp, phụ cấp và tiền lương cơ sở 2.340.000 đồng và chi phí quản lý 4% (chưa làm tròn)\n\n(13)", "Giá đề nghị phê duyệt (làm tròn)\n\n(14)", "Mức giá do quỹ BHYT thanh toán\n\n(15)",
    "Mức giá không thuộc quỹ BHYT thanh toán\n\n(16)", "Ghi chú gốc\n\n(17)", "Ghi chú của đơn vị\n\n(18)"
  ];
}

export function getPL5HeaderRow() {
  return [
    "STT\n\n(1)", "Mã DVKT dùng chung\n\n(2)", "Tên chương theo Thông tư số 23/2024/TT-BYT\n\n(3)", "Tên dịch vụ kỹ thuật theo Thông tư 23/2024/TT-BYT\n\n(4)", "Tên dịch vụ phê duyệt giá\n\n(5)",
    "Chi phí trực tiếp + Phụ cấp\n\n(6)", "Tiền lương 2.340.000 đồng\n\n(7)", "Giá bao gồm chi phí trực tiếp, phụ cấp và tiền lương 2.340.000 đồng (chưa làm tròn)\n\n(8)",
    "Chi phí bao phim và phim\n\n(9)", "Giá chưa bao gồm chi phí bao phim và phim theo lương cơ sở 2.340.000 đồng (chưa làm tròn)\n\n(10)=(8) - (9)", "Chi phí quản lý (4%)\n\n(11)=(10)*4%",
    "Giá bao gồm chi phí trực tiếp, phụ cấp, tiền lương cơ sở 2.430.000 đồng và chi phí quản lý 4% (chưa làm tròn)\n\n(12)=(10)+(11)", "Giá đề nghị phê duyệt (làm tròn số học)\n\n(13)", "Mức giá do quỹ BHYT thanh toán\n\n(14)",
    "Mức giá không thuộc quỹ BHYT thanh toán\n\n(15)", "Ghi chú gốc(16)", "Ghi chú của đơn vị(17)"
  ];
}
