// Tự tạo Google Sheet cho mỗi phiên nộp: tải file .xlsx lên Google Drive và yêu cầu Drive chuyển thành Google Sheet.
// Chỉ bật khi có GOOGLE_SERVICE_ACCOUNT_JSON (hoặc _FILE) và GOOGLE_DRIVE_FOLDER_ID. Không cần thư viện ngoài.
import { createSign } from 'node:crypto';
import { readFileSync } from 'node:fs';

const SCOPE = 'https://www.googleapis.com/auth/drive';
const SHEET_MIME = 'application/vnd.google-apps.spreadsheet';
const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

let tokenCache = { value: '', exp: 0 };

function loadCredentials(env = process.env) {
  let raw = env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!raw && env.GOOGLE_SERVICE_ACCOUNT_FILE) raw = readFileSync(env.GOOGLE_SERVICE_ACCOUNT_FILE, 'utf8');
  if (!raw) return null;
  const c = JSON.parse(raw);
  return c.client_email && c.private_key ? c : null;
}

export function isEnabled(env = process.env) {
  try { return !!(loadCredentials(env) && env.GOOGLE_DRIVE_FOLDER_ID); } catch { return false; }
}

const b64url = (b) => Buffer.from(b).toString('base64url');

export function signJwt(cred, now = Math.floor(Date.now() / 1000)) {
  const head = b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const body = b64url(JSON.stringify({ iss: cred.client_email, scope: SCOPE, aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  const sig = createSign('RSA-SHA256').update(`${head}.${body}`).sign(cred.private_key).toString('base64url');
  return `${head}.${body}.${sig}`;
}

async function accessToken(cred) {
  const now = Date.now();
  if (tokenCache.value && tokenCache.exp > now + 60000) return tokenCache.value;
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: signJwt(cred) }),
  });
  const j = await res.json();
  if (!res.ok || !j.access_token) throw new Error(`Google OAuth: ${j.error_description || j.error || res.status}`);
  tokenCache = { value: j.access_token, exp: now + (j.expires_in || 3600) * 1000 };
  return tokenCache.value;
}

/** Tải buffer .xlsx lên thư mục Drive và chuyển thành Google Sheet. Trả về đường dẫn mở Sheet. */
export async function uploadAsSheet(name, xlsxBuffer, env = process.env) {
  const cred = loadCredentials(env);
  const folder = env.GOOGLE_DRIVE_FOLDER_ID;
  if (!cred || !folder) throw new Error('Chưa cấu hình Google Drive');
  const token = await accessToken(cred);
  const boundary = 'dvkt' + Date.now().toString(16);
  const meta = JSON.stringify({ name, mimeType: SHEET_MIME, parents: [folder] });
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n`),
    Buffer.from(`--${boundary}\r\nContent-Type: ${XLSX_MIME}\r\n\r\n`),
    xlsxBuffer,
    Buffer.from(`\r\n--${boundary}--`),
  ]);
  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,webViewLink', {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': `multipart/related; boundary=${boundary}` },
    body,
  });
  const file = await res.json();
  if (!res.ok || !file.id) throw new Error(`Google Drive: ${file.error?.message || res.status}`);
  if ((env.GOOGLE_SHEET_SHARE || 'anyone') === 'anyone') {
    const p = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}/permissions?supportsAllDrives=true`, {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ role: 'reader', type: 'anyone' }),
    });
    if (!p.ok) throw new Error(`Google Drive (chia sẻ): ${p.status}`);
  }
  return file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`;
}
