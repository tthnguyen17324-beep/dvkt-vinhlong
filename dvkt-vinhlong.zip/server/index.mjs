import { buildApp } from './app.mjs';

const port = Number(process.env.PORT || 8000);
const host = process.env.HOST || '0.0.0.0';

const app = await buildApp({ logger: { level: 'info' } });
await app.listen({ port, host });
console.log(`\nHệ thống đang chạy: http://localhost:${port}\n`);
