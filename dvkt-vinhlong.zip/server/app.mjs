import Fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import multipart from '@fastify/multipart';
import rateLimit from '@fastify/rate-limit';
import { mkdirSync, writeFileSync, unlinkSync, existsSync, readFileSync } from 'node:fs';
import { resolve, extname, join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { openDb, tx, checkToken, hashToken, DATA_DIR } from './db.mjs';
import { createCatalog, cleanKey, pl3Key, selectionsFromRows, summarizeRows } from './logic.mjs';
import { buildReportWorkbook } from './export.mjs';
import * as gsheets from './gsheets.mjs';
import { getPL1HeaderRow, getPL2HeaderRow, getPL3HeaderRow, getPL4HeaderRow, getPL5HeaderRow } from './headers.mjs';

const TITLE = 'HỆ THỐNG XÂY DỰNG GIÁ DỊCH VỤ KHÁM BỆNH, CHỮA BỆNH TẠI TỈNH VĨNH LONG';
const PLS = ['pl1', 'pl2', 'pl3', 'pl4', 'pl5'];
const FILE_RULES = {
  QD_XepHangBV_hoac_QD_ThanhlapTYT: { max: 1 * 1024 * 1024, pdfOnly: true },
  HoSo_MinhChungKhac: { max: 5 * 1024 * 1024 },
  QD_PheDuyetDVKT: { max: 10 * 1024 * 1024, pdfOnly: true },
  QD_DuDieuKienKSK: { max: 1 * 1024 * 1024, pdfOnly: true },
};
const BLOCKED_EXT = new Set(['.exe', '.bat', '.cmd', '.com', '.sh', '.js', '.mjs', '.msi', '.scr', '.php', '.html', '.htm', '.svg', '.ps1', '.vbs', '.jar']);

const fmtTime = (ms) => {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).formatToParts(new Date(ms)).map((x) => [x.type, x.value]));
  return `${p.day}/${p.month}/${p.year} ${p.hour}:${p.minute}:${p.second}`;
};
const fail = (message, extra = {}) => ({ success: false, message, ...extra });
const BAD_TOKEN = 'Mã xác thực Token không chính xác!';

export async function buildApp({ dbPath, adminPassword = process.env.ADMIN_PASSWORD, logger = false } = {}) {
  if (!adminPassword) throw new Error('Chưa cấu hình ADMIN_PASSWORD (xem file .env.example).');
  const db = openDb(dbPath);
  const catalog = createCatalog(db);
  const app = Fastify({ logger, bodyLimit: 8 * 1024 * 1024, trustProxy: true });
  await app.register(rateLimit, { global: false });
  await app.register(multipart, { limits: { fileSize: 11 * 1024 * 1024, files: 1 } });

  const q = {
    unit: db.prepare('SELECT * FROM units WHERE ma = ?'),
    latestSub: db.prepare('SELECT * FROM submissions WHERE ma = ? ORDER BY ts DESC, id DESC LIMIT 1'),
    state: db.prepare('SELECT * FROM unit_state WHERE ma = ?'),
    sels: db.prepare('SELECT pl, key, note, chuong FROM selections WHERE ma = ?'),
  };

  const isLocked = (ma) => {
    const s = q.latestSub.get(ma);
    return !!s && String(s.status).trim().toLowerCase() === 'đã khóa';
  };
  const getState = (ma) => q.state.get(ma) || { ma, loai_hinh: 'H2', meta_json: '{}', version: 0, updated_at: 0 };
  const bump = (ma, patchMeta) => {
    const st = getState(ma);
    const meta = { ...JSON.parse(st.meta_json || '{}'), ...(patchMeta || {}) };
    db.prepare(`INSERT INTO unit_state (ma, loai_hinh, meta_json, version, updated_at) VALUES (?,?,?,?,?)
      ON CONFLICT(ma) DO UPDATE SET loai_hinh = excluded.loai_hinh, meta_json = excluded.meta_json,
      version = excluded.version, updated_at = excluded.updated_at`)
      .run(ma, meta.loaiHinh || st.loai_hinh || 'H2', JSON.stringify(meta), (st.version || 0) + 1, Date.now());
  };

  /** Xác thực theo Mã đơn vị + Token (header), như verifyToken cũ. */
  const authUnit = (req) => {
    const ma = String(req.headers['x-unit'] || '').trim().toUpperCase();
    const token = String(req.headers['x-token'] || '').trim();
    if (!ma || !token) return null;
    const u = q.unit.get(ma);
    return u && checkToken(token, u.token_hash) ? u : null;
  };
  const authAdmin = (req) => {
    const pw = String(req.headers['x-admin'] || '').trim();
    return pw !== '' && pw === String(adminPassword).trim();
  };

  const selectionMap = (ma) => {
    const out = { pl1: {}, pl2: {}, pl3: {}, pl4: {}, pl5: {} };
    for (const r of q.sels.all(ma)) out[r.pl][r.key] = { tichChon: true, ghiChu: r.note, ...(r.pl === 'pl3' ? { chuong: r.chuong } : {}) };
    return out;
  };
  const filesOf = (ma, subId) => db.prepare(
    'SELECT id, type_label, name FROM files WHERE ma = ? AND submission_id IS ? ORDER BY id',
  ).all(ma, subId ?? null).map((f) => ({ id: f.id, typeLabel: f.type_label, name: f.name, cleanName: f.name }));

  const rowsFor = (ma, loaiHinh) => {
    const sel = selectionMap(ma);
    const rows = {};
    for (const pl of PLS) rows[pl] = catalog.buildExportRows(pl, loaiHinh, sel[pl]);
    return rows;
  };

  // Tạo Google Sheet cho phiên (nếu đã cấu hình Google). Chạy nền, lỗi chỉ ghi log, không chặn việc nộp.
  const sheetJobs = new Set();
  const ensureSheet = (sub) => {
    if (!gsheets.isEnabled() || !sub || !sub.snapshot_json || sub.sheet_url || sheetJobs.has(sub.id)) return;
    sheetJobs.add(sub.id);
    (async () => {
      const snap = JSON.parse(sub.snapshot_json);
      const wb = await buildReportWorkbook({ tenDonVi: sub.ten, timeFormatted: fmtTime(sub.ts), isTYT: snap.loaiHinh === 'TYT', rows: snap.rows });
      const url = await gsheets.uploadAsSheet(`BaoCao_DVKT_${sub.ten}_Phiên_${fmtTime(sub.ts).replace(/[/: ]/g, '-')}`, Buffer.from(await wb.xlsx.writeBuffer()));
      db.prepare('UPDATE submissions SET sheet_url = ? WHERE id = ?').run(url, sub.id);
    })().catch((e) => app.log.error({ err: e.message, sub: sub.id }, 'Không tạo được Google Sheet'))
      .finally(() => sheetJobs.delete(sub.id));
  };

  // ---------- Công khai ----------
  app.get('/api/config', async () => ({
    title: TITLE,
    cpqlAppUrl: process.env.CPQL_APP_URL || '',
    maxOtherAttachmentBytes: FILE_RULES.HoSo_MinhChungKhac.max,
  }));

  app.get('/api/hospitals', async () => {
    const list = db.prepare('SELECT ma, ten, email FROM units ORDER BY rowid').all()
      .filter((u) => !isLocked(u.ma));
    return { success: true, hospitals: list };
  });
  app.get('/api/lookup-hospitals', async () => ({
    success: true, hospitals: db.prepare('SELECT ma, ten FROM units ORDER BY rowid').all(),
  }));

  app.post('/api/verify', { config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req) => {
    const { ma, token } = req.body || {};
    const u = q.unit.get(String(ma || '').trim().toUpperCase());
    if (!u || !checkToken(String(token || '').trim(), u.token_hash)) return { isValid: false };
    const st = getState(u.ma);
    return {
      isValid: true, tenDonVi: u.ten, email: u.email, noiDungBoSung: u.noi_dung_bo_sung, ketQuaBoSung: u.ket_qua_bo_sung,
      isLocked: isLocked(u.ma), loaiHinh: st.loai_hinh,
    };
  });

  app.get('/api/headers', async () => ({
    pl1: getPL1HeaderRow(), pl2: getPL2HeaderRow(), pl3: getPL3HeaderRow(true), pl4: getPL4HeaderRow(), pl5: getPL5HeaderRow(),
  }));

  // ---------- Danh mục ----------
  app.get('/api/catalog/pl1', async (req) => ({ success: true, data: catalog.getPL1(req.query.lh) }));
  app.get('/api/catalog/pl2', async (req) => ({ success: true, data: catalog.getPL2(req.query.lh) }));
  app.get('/api/catalog/pl3/chapters', async (req) => catalog.getPL3Chapters(req.query.tyt === '1'));
  app.get('/api/catalog/pl3/chapter-map', async (req) => catalog.getPL3ItemChapterMap(req.query.tyt === '1'));
  app.get('/api/catalog/pl3/chapter', async (req) => ({ success: true, data: catalog.getPL3ByChapter(req.query.tyt === '1', req.query.name) }));
  app.get('/api/catalog/pl4', async () => ({ success: true, data: catalog.getFull('pl4') }));
  app.get('/api/catalog/pl5', async () => ({ success: true, data: catalog.getFull('pl5') }));
  app.post('/api/match-excel', async (req) => {
    const { pl, isTYT, entries } = req.body || {};
    if (!['pl3', 'pl4', 'pl5'].includes(pl)) return fail('Phụ lục không hợp lệ');
    return { success: true, list: catalog.matchExcel(pl, !!isTYT, entries) };
  });

  // ---------- Trạng thái đơn vị (thay Firebase) ----------
  app.get('/api/state', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    const st = getState(u.ma);
    const since = Number(req.query.since);
    if (Number.isFinite(since) && since === st.version && req.query.since !== undefined) return { success: true, unchanged: true, version: st.version };
    return {
      success: true, version: st.version,
      meta: { ...JSON.parse(st.meta_json || '{}'), loaiHinh: st.loai_hinh },
      selections: selectionMap(u.ma),
      files: filesOf(u.ma, null),
      locked: isLocked(u.ma),
      noiDungBoSung: u.noi_dung_bo_sung, ketQuaBoSung: u.ket_qua_bo_sung,
    };
  });

  app.put('/api/meta', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    if (isLocked(u.ma)) return fail('Đơn vị đã được khóa. Vui lòng liên hệ Sở Y tế để mở khóa.');
    const b = req.body || {};
    const meta = {};
    for (const k of ['loaiHinh', 'hoTen', 'khoaPhong', 'chucVu', 'soDienThoai', 'emailThaoTac', 'kskChecked']) if (b[k] !== undefined) meta[k] = b[k];
    if (meta.loaiHinh && !['H1', 'H2', 'H3', 'H4', 'TYT'].includes(meta.loaiHinh)) return fail('Loại hình không hợp lệ');
    meta.updatedAt = Date.now();
    meta.lastUpdatedBy = b.hoTen || '';
    bump(u.ma, meta);
    return { success: true, version: getState(u.ma).version };
  });

  app.put('/api/selections', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    if (isLocked(u.ma)) return fail('Đơn vị đã được khóa. Vui lòng liên hệ Sở Y tế để mở khóa.');
    const { pl, items, replaceAll } = req.body || {};
    if (!PLS.includes(pl) || !Array.isArray(items)) return fail('Dữ liệu không hợp lệ');
    const st = getState(u.ma);
    const chMap = pl === 'pl3' ? catalog.getPL3ItemChapterMap(st.loai_hinh === 'TYT') : null;
    const ins = db.prepare(`INSERT INTO selections (ma, pl, key, note, chuong) VALUES (?,?,?,?,?)
      ON CONFLICT(ma, pl, key) DO UPDATE SET note = excluded.note, chuong = excluded.chuong`);
    const del = db.prepare('DELETE FROM selections WHERE ma = ? AND pl = ? AND key = ?');
    tx(db, () => {
      if (replaceAll) db.prepare('DELETE FROM selections WHERE ma = ? AND pl = ?').run(u.ma, pl);
      for (const it of items.slice(0, 20000)) {
        const key = cleanKey(it.key);
        if (!key) continue;
        if (it.tichChon === false) del.run(u.ma, pl, key);
        else ins.run(u.ma, pl, key, String(it.ghiChu || '').slice(0, 2000), pl === 'pl3' ? String(it.chuong || (chMap && chMap[key]) || '') : '');
      }
      bump(u.ma);
    });
    return { success: true, version: getState(u.ma).version };
  });

  // ---------- File đính kèm ----------
  app.post('/api/files', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    if (isLocked(u.ma)) return fail('Đơn vị đã được khóa. Vui lòng liên hệ Sở Y tế để mở khóa.');
    const part = await req.file();
    if (!part) return fail('Không nhận được tệp');
    const typeLabel = String(part.fields.typeLabel?.value || '');
    const rule = FILE_RULES[typeLabel];
    if (!rule) return fail('Loại hồ sơ không hợp lệ');
    const buf = await part.toBuffer();
    if (part.file.truncated || buf.length > rule.max) return fail(`Tệp vượt quá ${(rule.max / 1048576)}MB`);
    const name = String(part.filename || 'tep').replace(/[\\/:*?"<>|\r\n]/g, '_').slice(0, 150);
    const ext = extname(name).toLowerCase();
    if (BLOCKED_EXT.has(ext)) return fail('Định dạng tệp không được phép');
    if (rule.pdfOnly && (ext !== '.pdf' || buf.subarray(0, 4).toString() !== '%PDF')) return fail('Chỉ chấp nhận tệp PDF');
    const dir = resolve(DATA_DIR, 'files', u.ma);
    mkdirSync(dir, { recursive: true });
    const path = join(dir, `${Date.now()}-${randomBytes(4).toString('hex')}${ext}`);
    writeFileSync(path, buf);
    tx(db, () => {
      const old = db.prepare('SELECT id, path FROM files WHERE ma = ? AND submission_id IS NULL AND type_label = ?').all(u.ma, typeLabel);
      for (const o of old) { try { unlinkSync(o.path); } catch { /* đã xóa */ } db.prepare('DELETE FROM files WHERE id = ?').run(o.id); }
      db.prepare('INSERT INTO files (ma, submission_id, type_label, name, path, size, created_at) VALUES (?,?,?,?,?,?,?)')
        .run(u.ma, null, typeLabel, name, path, buf.length, Date.now());
      bump(u.ma);
    });
    return { success: true, files: filesOf(u.ma, null) };
  });

  const sendFile = (reply, f) => {
    if (!f || !existsSync(f.path)) return reply.code(404).send(fail('Không tìm thấy tệp'));
    reply.header('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}`);
    reply.header('X-Content-Type-Options', 'nosniff');
    return reply.type('application/octet-stream').send(readFileSync(f.path));
  };
  app.get('/api/files/:id', async (req, reply) => {
    const u = authUnit(req);
    if (!u) return reply.code(401).send(fail(BAD_TOKEN));
    return sendFile(reply, db.prepare('SELECT * FROM files WHERE id = ? AND ma = ?').get(Number(req.params.id), u.ma));
  });

  // ---------- Lưu tạm / Nộp chính thức ----------
  app.post('/api/save', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    if (isLocked(u.ma)) return fail('Đơn vị đã được khóa. Vui lòng liên hệ Sở Y tế để mở khóa.');
    const b = req.body || {};
    const meta = {};
    for (const k of ['loaiHinh', 'hoTen', 'khoaPhong', 'chucVu', 'soDienThoai', 'emailThaoTac', 'kskChecked']) if (b[k] !== undefined) meta[k] = b[k];
    meta.updatedAt = Date.now();
    if (!b.isFinalSubmit) {
      bump(u.ma, meta);
      return { success: true, message: 'Đã lưu tạm dữ liệu thành công!', files: filesOf(u.ma, null) };
    }

    // Nộp chính thức: kiểm tra lại đủ hồ sơ trên máy chủ
    bump(u.ma, meta);
    const st = getState(u.ma);
    const m = JSON.parse(st.meta_json || '{}');
    const loaiHinh = st.loai_hinh || m.loaiHinh || 'H2';
    const files = filesOf(u.ma, null);
    const has = (t) => files.some((f) => f.typeLabel === t);
    const missing = [];
    for (const [k, label] of [['hoTen', 'Họ và tên'], ['khoaPhong', 'Khoa / Phòng'], ['chucVu', 'Chức vụ'], ['soDienThoai', 'Số điện thoại'], ['emailThaoTac', 'Email']]) {
      if (!String(m[k] || '').trim()) missing.push(label);
    }
    if (!has('QD_XepHangBV_hoac_QD_ThanhlapTYT')) missing.push('Quyết định xếp hạng Bệnh viện / Quyết định thành lập Trạm Y tế');
    if (!has('QD_PheDuyetDVKT')) missing.push('Quyết định phê duyệt dịch vụ kỹ thuật');
    if (m.kskChecked && !has('QD_DuDieuKienKSK')) missing.push('Quyết định / Thông báo đủ điều kiện khám sức khỏe');
    if (missing.length) return fail('Hồ sơ chưa đầy đủ: ' + missing.join('; '));

    const rows = rowsFor(u.ma, loaiHinh);
    const sum = summarizeRows(rows);
    const now = Date.now();
    const id = tx(db, () => {
      const r = db.prepare(`INSERT INTO submissions (ts, ma, ten, ho_ten, khoa_phong, chuc_vu, sdt, email, status, loai_hinh,
        pl1_kb, pl1_hc, pl1_gd, pl1_skld, pl1_xkd, c2, c3, c4, c5, total_kt, snapshot_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        now, u.ma, u.ten, m.hoTen || '', m.khoaPhong || '', m.chucVu || '', m.soDienThoai || '', m.emailThaoTac || '',
        'Đã khóa', loaiHinh, sum.flags.kb, sum.flags.hc, sum.flags.gd, sum.flags.skld, sum.flags.xkd,
        sum.c2, sum.c3, sum.c4, sum.c5, sum.total, JSON.stringify({ loaiHinh, rows }),
      );
      const sid = Number(r.lastInsertRowid);
      db.prepare('UPDATE files SET submission_id = ? WHERE ma = ? AND submission_id IS NULL').run(sid, u.ma);
      return sid;
    });
    const t = fmtTime(now);
    ensureSheet(db.prepare('SELECT * FROM submissions WHERE id = ?').get(id));
    return {
      success: true, submissionId: id,
      message: `Đã gửi báo cáo thành công lúc ${t}!\nĐơn vị đã được khóa để Hội đồng tổng hợp.\n(Quý đơn vị có thể tra cứu lại đường link Báo cáo và hồ sơ tại mục Tra cứu).`,
    };
  });

  // ---------- Lịch sử / khôi phục ----------
  app.get('/api/sessions', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    const list = db.prepare('SELECT * FROM submissions WHERE ma = ? ORDER BY ts DESC, id DESC').all(u.ma).map((s) => ({
      id: s.id, timestamp: s.ts, timeFormatted: fmtTime(s.ts), hoTen: s.ho_ten, khoaPhong: s.khoa_phong, chucVu: s.chuc_vu,
      soDienThoai: s.sdt, email: s.email, folderUrl: s.legacy_folder_url, status: s.status || 'Đã khóa', hasSnapshot: !!s.snapshot_json,
    }));
    return { success: true, list, tenDonVi: u.ten };
  });

  app.post('/api/restore', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    if (isLocked(u.ma)) return fail('Đơn vị đã được khóa. Vui lòng liên hệ Sở Y tế để mở khóa.');
    const sub = db.prepare('SELECT * FROM submissions WHERE id = ? AND ma = ?').get(Number(req.body?.id), u.ma);
    if (!sub || !sub.snapshot_json) return fail('Chưa có dữ liệu báo cáo cho phiên này!', { isNewSession: true });
    const snap = JSON.parse(sub.snapshot_json);
    const saved = selectionsFromRows(snap.rows);
    const ins = db.prepare('INSERT INTO selections (ma, pl, key, note, chuong) VALUES (?,?,?,?,?)');
    tx(db, () => {
      db.prepare('DELETE FROM selections WHERE ma = ?').run(u.ma);
      for (const pl of PLS) for (const [k, v] of Object.entries(saved[pl])) ins.run(u.ma, pl, k, v.ghiChu || '', v.chuong || '');
      bump(u.ma, { loaiHinh: snap.loaiHinh });
    });
    const counts = Object.fromEntries(PLS.map((p, i) => [`c${i + 1}`, Object.keys(saved[p]).length]));
    counts.total = Object.values(counts).reduce((a, b) => a + b, 0);
    return { success: true, savedSelections: saved, counts, loaiHinh: snap.loaiHinh, files: filesOf(u.ma, sub.id) };
  });

  // ---------- Tra cứu phiên cuối ----------
  app.get('/api/lookup', async (req) => {
    const u = authUnit(req);
    if (!u) return fail(BAD_TOKEN);
    const s = q.latestSub.get(u.ma);
    if (!s) return fail('Đơn vị chưa có phiên báo cáo nào được ghi nhận trên hệ thống!');
    const locked = String(s.status).trim().toLowerCase() === 'đã khóa';
    ensureSheet(s); // thử lại nếu lần tạo trước bị lỗi
    return {
      success: true, sheetUrl: s.sheet_url || '', tenDonVi: u.ten, timeFormatted: fmtTime(s.ts), hoTen: s.ho_ten, khoaPhong: s.khoa_phong, chucVu: s.chuc_vu,
      soDienThoai: s.sdt, email: s.email, status: locked ? 'Đã khóa' : 'Đang mở khóa', isLocked: locked,
      folderUrl: s.legacy_folder_url, submissionId: s.id, hasSnapshot: !!s.snapshot_json, thuyetMinhCPQLSheetUrl: s.cpql_url,
      attachedFiles: filesOf(u.ma, s.id),
      noiDungYeuCauBoSung: u.noi_dung_bo_sung || 'Không có yêu cầu bổ sung', ketQuaBoSung: u.ket_qua_bo_sung || '',
      counts: { pl1_kb: s.pl1_kb, pl1_hc: s.pl1_hc, pl1_gd: s.pl1_gd, pl1_skld: s.pl1_skld, pl1_xkd: s.pl1_xkd, c2: s.c2, c3: s.c3, c4: s.c4, c5: s.c5, totalKT: s.total_kt || s.c3 + s.c4 + s.c5 },
    };
  });

  const sendWorkbook = async (reply, name, wb) => {
    const buf = await wb.xlsx.writeBuffer();
    reply.header('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(name)}`);
    return reply.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').send(Buffer.from(buf));
  };
  const reportOf = async (reply, sub) => {
    if (!sub || !sub.snapshot_json) return reply.code(404).send(fail('Phiên này chỉ có liên kết Google Drive cũ, không có dữ liệu để xuất.'));
    const snap = JSON.parse(sub.snapshot_json);
    const wb = await buildReportWorkbook({ tenDonVi: sub.ten, timeFormatted: fmtTime(sub.ts), isTYT: snap.loaiHinh === 'TYT', rows: snap.rows });
    return sendWorkbook(reply, `BaoCao_DVKT_${sub.ten}_${sub.id}.xlsx`, wb);
  };
  app.get('/api/export', async (req, reply) => {
    const u = authUnit(req);
    if (!u) return reply.code(401).send(fail(BAD_TOKEN));
    if (req.query.draft === '1') {
      const st = getState(u.ma);
      const wb = await buildReportWorkbook({ tenDonVi: u.ten, timeFormatted: fmtTime(Date.now()), isTYT: st.loai_hinh === 'TYT', rows: rowsFor(u.ma, st.loai_hinh) });
      return sendWorkbook(reply, `BaoCao_DVKT_${u.ten}_luu_tam.xlsx`, wb);
    }
    return reportOf(reply, db.prepare('SELECT * FROM submissions WHERE id = ? AND ma = ?').get(Number(req.query.id), u.ma));
  });

  // ---------- Quản trị ----------
  const adminLimit = { config: { rateLimit: { max: 20, timeWindow: '1 minute' } } };
  app.post('/api/admin/summary', adminLimit, async (req) => {
    if (String(req.body?.password || '').trim() !== String(adminPassword).trim()) return fail('Mật khẩu quản trị không chính xác!');
    const meta = Object.fromEntries(db.prepare('SELECT ma, noi_dung_bo_sung a, ket_qua_bo_sung b FROM units').all().map((r) => [r.ma, r]));
    const latest = new Map();
    for (const s of db.prepare("SELECT * FROM submissions ORDER BY ts DESC, id DESC").all()) {
      if (!latest.has(s.ma)) latest.set(s.ma, s);
    }
    const list = [];
    for (const s of latest.values()) {
      if (String(s.status).trim().toLowerCase() !== 'đã khóa') continue;
      const mt = meta[s.ma] || {};
      list.push({
        id: s.id, ma: s.ma, ten: s.ten || s.ma, time: fmtTime(s.ts).slice(0, 16),
        pl1_kb: s.pl1_kb, pl1_hc: s.pl1_hc, pl1_gd: s.pl1_gd, pl1_skld: s.pl1_skld, pl1_xkd: s.pl1_xkd,
        c2: s.c2, c3: s.c3, c4: s.c4, c5: s.c5, totalKT: s.c3 + s.c4 + s.c5,
        folderUrl: s.legacy_folder_url, hasSnapshot: !!s.snapshot_json, sheetUrl: s.sheet_url || '',
        noiDungYeuCauBoSung: mt.a || '', ketQuaBoSung: mt.b || '',
      });
    }
    return { success: true, list };
  });
  app.get('/api/admin/export/:id', adminLimit, async (req, reply) => {
    if (!authAdmin(req)) return reply.code(401).send(fail('Mật khẩu quản trị không chính xác!'));
    return reportOf(reply, db.prepare('SELECT * FROM submissions WHERE id = ?').get(Number(req.params.id)));
  });
  app.get('/api/admin/files/:id', adminLimit, async (req, reply) => {
    if (!authAdmin(req)) return reply.code(401).send(fail('Mật khẩu quản trị không chính xác!'));
    return sendFile(reply, db.prepare('SELECT * FROM files WHERE id = ?').get(Number(req.params.id)));
  });
  app.get('/api/admin/submission-files/:id', adminLimit, async (req, reply) => {
    if (!authAdmin(req)) return reply.code(401).send(fail('Mật khẩu quản trị không chính xác!'));
    const s = db.prepare('SELECT ma FROM submissions WHERE id = ?').get(Number(req.params.id));
    return { success: true, files: s ? filesOf(s.ma, Number(req.params.id)) : [] };
  });
  app.post('/api/admin/unlock', adminLimit, async (req) => {
    if (String(req.body?.password || '').trim() !== String(adminPassword).trim()) return fail('Mật khẩu quản trị không chính xác!');
    const ma = String(req.body?.ma || '').trim().toUpperCase();
    const s = q.latestSub.get(ma);
    if (!s) return fail('Không tìm thấy phiên nộp của đơn vị');
    db.prepare("UPDATE submissions SET status = 'Đang mở khóa' WHERE id = ?").run(s.id);
    return { success: true };
  });
  app.post('/api/admin/unit', adminLimit, async (req) => {
    const b = req.body || {};
    if (String(b.password || '').trim() !== String(adminPassword).trim()) return fail('Mật khẩu quản trị không chính xác!');
    const ma = String(b.ma || '').trim().toUpperCase();
    if (!q.unit.get(ma)) return fail('Không tìm thấy đơn vị');
    if (b.token) db.prepare('UPDATE units SET token_hash = ? WHERE ma = ?').run(hashToken(String(b.token)), ma);
    if (b.noiDungBoSung !== undefined) db.prepare('UPDATE units SET noi_dung_bo_sung = ? WHERE ma = ?').run(String(b.noiDungBoSung), ma);
    if (b.ketQuaBoSung !== undefined) db.prepare('UPDATE units SET ket_qua_bo_sung = ? WHERE ma = ?').run(String(b.ketQuaBoSung), ma);
    return { success: true };
  });

  // ---------- Số thiết bị đang kết nối ----------
  const presence = new Map();
  app.post('/api/presence', async (req) => {
    const id = String(req.body?.id || '').slice(0, 40);
    const now = Date.now();
    if (id) presence.set(id, now);
    for (const [k, t] of presence) if (now - t > 45000) presence.delete(k);
    return { count: presence.size };
  });

  await app.register(fastifyStatic, { root: resolve('./public'), index: 'index.html' });
  app.addHook('onClose', async () => db.close());
  app.decorate('db', db);
  return app;
}
