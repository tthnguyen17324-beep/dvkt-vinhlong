// Logic nghiệp vụ - chuyển nguyên từ 2_Catalog.gs, 3_SaveSubmit.gs, 4_History.gs.
export const cleanKey = (s) =>
  s === undefined || s === null ? '' : String(s).trim().toLowerCase().replace(/^'+/, '').replace(/\s+/g, ' ');

const ALL_LH = ['H1', 'H2', 'H3', 'H4', 'TYT'];
const MAP_TEN_HANG = {
  H1: 'BỆNH VIỆN HẠNG I', H2: 'BỆNH VIỆN HẠNG II', H3: 'BỆNH VIỆN HẠNG III',
  H4: 'BỆNH VIỆN HẠNG IV', TYT: 'TRẠM Y TẾ',
};

export const pl3Key = (maChung, maKT) => {
  const c = cleanKey(maChung), k = cleanKey(maKT);
  return c ? `${c}_${k}` : k;
};

/** Bộ nhớ đệm danh mục: dữ liệu tĩnh nên đọc 1 lần cho mỗi tiến trình. */
export function createCatalog(db) {
  const cache = new Map();
  const load = (kind) => {
    if (!cache.has(kind)) {
      const rows = db.prepare('SELECT row_json FROM catalog WHERE kind = ? ORDER BY seq').all(kind)
        .map((r) => JSON.parse(r.row_json));
      cache.set(kind, rows);
    }
    return cache.get(kind);
  };
  const pl3Kind = (isTYT) => (isTYT ? 'pl3_tyt' : 'pl3_bv');

  function getPL1(loaiHinh) {
    const target = String(loaiHinh || '').toUpperCase();
    const data = load('pl1');
    const result = [{ sttDisplay: '', ten: `HẠNG BỆNH VIỆN / CƠ SỞ: ${MAP_TEN_HANG[target] || target}`, isHeader: true, hasAction: false }];
    const kb = data.find((r) => String(r[13] || '').trim().toUpperCase() === target);
    if (kb) {
      result.push({
        sttDisplay: '1', ten: 'Khám bệnh',
        c3: kb[2], c4: kb[3], c5: kb[4], c6: kb[5], c7: kb[6], c8: kb[7], c9: kb[8],
        giaDeNghi: kb[9], giaBHYT: kb[10], giaKhongBHYT: kb[11], ghiChuGoc: kb[12] || '', hasAction: true,
      });
    }
    let stt = 2;
    for (const r of data) {
      const sttRaw = String(r[0] || '').trim();
      const ten = String(r[1] || '').trim();
      const lh = String(r[13] || '').trim().toUpperCase();
      if (ALL_LH.includes(lh)) continue;
      if (ten.toLowerCase() === 'khám bệnh') continue;
      if (!ten) continue;
      const isHead = sttRaw === '';
      result.push({
        sttDisplay: isHead ? '' : String(stt++), ten,
        c3: r[2], c4: r[3], c5: r[4], c6: r[5], c7: r[6], c8: r[7], c9: r[8],
        giaDeNghi: r[9], giaBHYT: r[10], giaKhongBHYT: r[11], ghiChuGoc: r[12] || '',
        isHeader: isHead, hasAction: !isHead,
      });
    }
    return result;
  }

  function getPL2(loaiHinh) {
    const target = String(loaiHinh || '').toUpperCase();
    const others = ALL_LH.filter((h) => h !== target);
    const data = load('pl2');
    const result = [];
    for (const r of data) {
      const sttRaw = String(r[0] || '').trim();
      const ten = String(r[1] || '').trim();
      const lh = String(r[r.length - 1] || '').trim().toUpperCase();
      if (!ten) continue;
      if (others.includes(lh)) continue;
      const hasPrice = (r[2] !== '' && r[2] !== null) || (r[10] !== '' && r[10] !== null);
      if (!sttRaw && !hasPrice) continue;
      const isGroup = sttRaw === '3' || sttRaw === '4';
      result.push({
        sttDisplay: sttRaw, ten: ten.replace(/Hạng\s+[I|V|X|1-4]+/gi, '').trim(),
        c3: r[2], c4: r[3], c5: r[4], c6: r[5], c7: r[6], c8: r[7], c9: r[8], c10: r[9],
        giaDeNghi: r[10], giaBHYT: r[11], giaKhongBHYT: r[12], ghiChuGoc: r[13] || '',
        isHeader: isGroup, hasAction: !isGroup,
      });
    }
    return result;
  }

  function getPL3Chapters(isTYT) {
    const order = [], count = {};
    for (const r of load(pl3Kind(isTYT))) {
      const ch = String(r[2] || '').trim();
      if (!ch) continue;
      if (!count[ch]) { count[ch] = 0; order.push(ch); }
      count[ch]++;
    }
    return order.map((name) => ({ name, count: count[name] }));
  }

  function getPL3ItemChapterMap(isTYT) {
    const map = {};
    for (const r of load(pl3Kind(isTYT))) {
      const raw = String(r[1] || '').trim().toLowerCase().replace(/\s+/g, ' ');
      const ch = String(r[2] || '').trim();
      const kt = String(r[3] || '').trim().toLowerCase().replace(/\s+/g, ' ');
      const k = raw ? `${raw}_${kt}` : kt;
      if (k && ch) map[k] = ch;
    }
    return map;
  }

  function getPL3ByChapter(isTYT, chapterName) {
    const target = String(chapterName || '').trim().toLowerCase();
    if (!target) return [];
    const out = [];
    for (const r of load(pl3Kind(isTYT))) {
      if (String(r[2] || '').trim().toLowerCase() === target) {
        out.push({ rowValues: r, maDungChung: r[1], maKyThuat: r[3], tenKyThuat: r[4], tenPheDuyet: r[5], giaDeNghi: isTYT ? r[14] : r[13] });
      }
    }
    return out;
  }

  function getFull(kind) {
    const out = [];
    for (const r of load(kind)) {
      if (!r[1] && !r[4]) continue;
      out.push({ rowValues: r, maDungChung: r[1], maKyThuat: r[3] || r[1], tenKyThuat: r[4] || r[3] });
    }
    return out;
  }

  function matchExcel(targetPL, isTYT, entries) {
    const kind = targetPL === 'pl3' ? pl3Kind(isTYT) : targetPL;
    const data = load(kind);
    const norm = (s) => String(s || '').trim().toLowerCase().replace(/[\s.\-_]/g, '');
    const cleanCh = (s) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
    const out = [], added = new Set();
    const byChuong = (cands, exChuong) => {
      const f = cands.filter((r) => { const c = cleanCh(r[2]); return c.includes(exChuong) || exChuong.includes(c); });
      return f.length ? f : cands;
    };
    for (const e of entries || []) {
      const exKT = norm(e.maKT), exChung = norm(e.maChung), exChuong = cleanCh(e.chuong);
      const note = String(e.note || '').trim();
      if (!exKT && !exChung) continue;
      let c = [];
      if (targetPL === 'pl3' || targetPL === 'pl4') {
        if (exKT) c = data.filter((r) => norm(r[3]) === exKT);
        if (c.length !== 1 && exChung) {
          const b = (c.length > 1 ? c : data).filter((r) => norm(r[1]) === exChung);
          if (b.length) c = b;
        }
        if (c.length > 1 && exChuong) c = byChuong(c, exChuong);
      } else if (targetPL === 'pl5') {
        if (exChung) c = data.filter((r) => norm(r[1]) === exChung);
        if (c.length > 1 && exChuong) c = byChuong(c, exChuong);
      }
      for (const r of c) {
        const mC = cleanCh(r[1]), mKT = cleanCh(r[3]);
        const uniqueKey = mC ? `${mC}_${mKT}` : mKT;
        if (added.has(uniqueKey)) continue;
        added.add(uniqueKey);
        out.push({ uniqueKey, chuong: String(r[2] || '').trim(), ghiChu: note, maChung: String(r[1] || '').trim(), maKT: String(r[3] || '').trim() });
      }
    }
    return out;
  }

  /** Dòng xuất PL1/2/4/5/3 từ tập chọn: sel = { key: {ghiChu} } */
  function buildExportRows(pl, loaiHinh, sel) {
    const isTYT = String(loaiHinh).toUpperCase() === 'TYT';
    const rows = [];
    let stt = 1;
    const pick = (k) => sel && Object.prototype.hasOwnProperty.call(sel, k);
    const noteOf = (k) => String((sel[k] && sel[k].ghiChu) || '');
    if (pl === 'pl1') {
      for (const i of getPL1(loaiHinh)) {
        const k = cleanKey(i.ten);
        if (i.hasAction && pick(k)) rows.push([stt++, i.ten, i.c3, i.c4, i.c5, i.c6, i.c7, i.c8, i.c9, i.giaDeNghi, i.giaBHYT, i.giaKhongBHYT, noteOf(k)]);
      }
    } else if (pl === 'pl2') {
      for (const i of getPL2(loaiHinh)) {
        const k = cleanKey(i.ten);
        if (i.hasAction && pick(k)) rows.push([stt++, i.ten, i.c3, i.c4, i.c5, i.c6, i.c7, i.c8, i.c9, i.c10, i.giaDeNghi, i.giaBHYT, i.giaKhongBHYT, noteOf(k)]);
      }
    } else if (pl === 'pl3') {
      const full = isTYT ? 18 : 17;
      for (const d of load(pl3Kind(isTYT))) {
        const k = pl3Key(d[1], d[3]);
        if (!pick(k)) continue;
        const r = d.slice(0, full);
        r[0] = stt++;
        r[1] = String(d[1] || '').trim();
        r[3] = String(d[3] || '').trim();
        r.push(noteOf(k));
        rows.push(r);
      }
    } else if (pl === 'pl4' || pl === 'pl5') {
      const width = pl === 'pl4' ? 17 : 16;
      for (const it of getFull(pl)) {
        const k = pl3Key(it.rowValues[1], it.rowValues[3]);
        if (!pick(k)) continue;
        const r = [...it.rowValues];
        r[0] = stt++;
        if (pl === 'pl5' && r[1] != null) r[1] = String(r[1]).trim();
        rows.push([...r.slice(0, width), noteOf(k)]);
      }
    }
    return rows;
  }

  return { getPL1, getPL2, getPL3Chapters, getPL3ItemChapterMap, getPL3ByChapter, getFull, matchExcel, buildExportRows };
}

/** Từ dòng đã xuất -> tập chọn (đọc lại phiên cũ), tương đương readUnitSheetData*. */
export function selectionsFromRows(rows) {
  const out = { pl1: {}, pl2: {}, pl3: {}, pl4: {}, pl5: {}, pl3ChapterCounts: {} };
  const last = (r) => String(r[r.length - 1] || '');
  for (const r of rows.pl1 || []) { const k = cleanKey(r[1]); if (k) out.pl1[k] = { tichChon: true, ghiChu: last(r) }; }
  for (const r of rows.pl2 || []) { const k = cleanKey(r[1]); if (k) out.pl2[k] = { tichChon: true, ghiChu: last(r) }; }
  for (const r of rows.pl3 || []) {
    const k = pl3Key(r[1], r[3]);
    if (k) out.pl3[k] = { tichChon: true, ghiChu: last(r), chuong: String(r[2] || '').trim() };
    const kc = cleanKey(r[2]);
    if (kc) out.pl3ChapterCounts[kc] = (out.pl3ChapterCounts[kc] || 0) + 1;
  }
  for (const pl of ['pl4', 'pl5']) {
    for (const r of rows[pl] || []) { const k = pl3Key(r[1], r[3]); if (k) out[pl][k] = { tichChon: true, ghiChu: last(r) }; }
  }
  return out;
}

/** Cờ PL1 và số lượng khi nộp chính thức (giữ nguyên quy tắc cũ). */
export function summarizeRows(rows) {
  const f = { kb: '', hc: '', gd: '', skld: '', xkd: '' };
  for (const r of rows.pl1 || []) {
    const n = String(r[1] || '').toLowerCase().trim();
    if (n.includes('khám bệnh')) f.kb = 'X';
    if (n.includes('hội chẩn')) f.hc = 'X';
    if (n.includes('chứng thương') || n.includes('giám định')) f.gd = 'X';
    if (n.includes('sức khỏe toàn diện lao động') || n.includes('định kỳ')) f.skld = 'X';
    if (n.includes('xuất khẩu lao động') || n.includes('xklđ')) f.xkd = 'X';
  }
  const c2 = (rows.pl2 || []).length, c3 = (rows.pl3 || []).length;
  const c4 = (rows.pl4 || []).length, c5 = (rows.pl5 || []).length;
  return { flags: f, c2, c3, c4, c5, total: c3 + c4 + c5 };
}
