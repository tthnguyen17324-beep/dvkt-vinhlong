import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { scryptSync, randomBytes, timingSafeEqual } from 'node:crypto';

export const DATA_DIR = resolve(process.env.DATA_DIR || './data');
export const DB_PATH = resolve(DATA_DIR, 'dvkt.db');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS units (
  ma TEXT PRIMARY KEY,
  ten TEXT NOT NULL,
  email TEXT DEFAULT '',
  token_hash TEXT DEFAULT '',
  noi_dung_bo_sung TEXT DEFAULT '',
  ket_qua_bo_sung TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS catalog (
  kind TEXT NOT NULL,
  seq INTEGER NOT NULL,
  chuong TEXT DEFAULT '',
  ma_chung TEXT DEFAULT '',
  ma_kt TEXT DEFAULT '',
  lh TEXT DEFAULT '',
  row_json TEXT NOT NULL,
  PRIMARY KEY (kind, seq)
);
CREATE INDEX IF NOT EXISTS idx_catalog_chuong ON catalog(kind, chuong);
CREATE TABLE IF NOT EXISTS unit_state (
  ma TEXT PRIMARY KEY,
  loai_hinh TEXT DEFAULT 'H2',
  meta_json TEXT DEFAULT '{}',
  version INTEGER DEFAULT 0,
  updated_at INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS selections (
  ma TEXT NOT NULL,
  pl TEXT NOT NULL,
  key TEXT NOT NULL,
  note TEXT DEFAULT '',
  chuong TEXT DEFAULT '',
  PRIMARY KEY (ma, pl, key)
);
CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  ma TEXT NOT NULL,
  ten TEXT DEFAULT '',
  ho_ten TEXT DEFAULT '',
  khoa_phong TEXT DEFAULT '',
  chuc_vu TEXT DEFAULT '',
  sdt TEXT DEFAULT '',
  email TEXT DEFAULT '',
  status TEXT DEFAULT 'Đã khóa',
  loai_hinh TEXT DEFAULT '',
  pl1_kb TEXT DEFAULT '', pl1_hc TEXT DEFAULT '', pl1_gd TEXT DEFAULT '',
  pl1_skld TEXT DEFAULT '', pl1_xkd TEXT DEFAULT '',
  c2 INTEGER DEFAULT 0, c3 INTEGER DEFAULT 0, c4 INTEGER DEFAULT 0, c5 INTEGER DEFAULT 0,
  total_kt INTEGER DEFAULT 0,
  legacy_folder_url TEXT DEFAULT '',
  cpql_url TEXT DEFAULT '',
  snapshot_json TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sub_ma ON submissions(ma, ts);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ma TEXT NOT NULL,
  submission_id INTEGER,
  type_label TEXT NOT NULL,
  name TEXT NOT NULL,
  path TEXT NOT NULL,
  size INTEGER DEFAULT 0,
  created_at INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_files_ma ON files(ma, submission_id);
`;

export function openDb(path = DB_PATH) {
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  // Nâng cấp CSDL cũ: thêm cột lưu liên kết Google Sheet của phiên (nếu chưa có)
  const cols = db.prepare('PRAGMA table_info(submissions)').all().map((c) => c.name);
  if (!cols.includes('sheet_url')) db.exec("ALTER TABLE submissions ADD COLUMN sheet_url TEXT DEFAULT ''");
  return db;
}

/** Chạy nhiều lệnh trong một transaction. */
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}

export function hashToken(token) {
  const salt = randomBytes(16).toString('hex');
  const h = scryptSync(String(token), salt, 32).toString('hex');
  return `${salt}:${h}`;
}

export function checkToken(token, stored) {
  if (!stored || !token) return false;
  const [salt, h] = stored.split(':');
  if (!salt || !h) return false;
  const calc = scryptSync(String(token), salt, 32);
  const real = Buffer.from(h, 'hex');
  return calc.length === real.length && timingSafeEqual(calc, real);
}
