// Xuất báo cáo .xlsx: cùng bố cục với writeToUnitSheet (3_SaveSubmit.gs): thông tin dòng 1-3, tiêu đề dòng 5, dữ liệu từ dòng 6.
import ExcelJS from 'exceljs';
import { getPL1HeaderRow, getPL2HeaderRow, getPL3HeaderRow, getPL4HeaderRow, getPL5HeaderRow } from './headers.mjs';

export function cleanNumberValue(val) {
  if (val === undefined || val === null || val === '') return '';
  if (val === '-' || val === '0' || val === 0) return val;
  if (typeof val === 'number') return Number.isNaN(val) ? '' : val;
  const str = String(val).trim();
  if (str === '-' || str === '') return str;
  let c = str.replace(/[^\d,.-]/g, '');
  if (!c) return str;
  if (c.includes('.') && c.includes(',')) {
    c = c.indexOf('.') < c.indexOf(',') ? c.replace(/\./g, '').replace(',', '.') : c.replace(/,/g, '');
  } else if (c.includes(',')) c = c.replace(',', '.');
  const n = Number(c);
  return Number.isNaN(n) ? str : Math.round(n);
}

const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);

export function sheetSpecs(isTYT) {
  return [
    { name: 'PL1', key: 'pl1', title: 'PHỤ LỤC 1: GIÁ DỊCH VỤ KHÁM BỆNH, HỘI CHẨN', header: getPL1HeaderRow(), price: range(3, 12) },
    { name: 'PL2', key: 'pl2', title: 'PHỤ LỤC 2: GIÁ DỊCH VỤ NGÀY GIƯỜNG BỆNH', header: getPL2HeaderRow(), price: range(3, 13) },
    { name: 'PL3', key: 'pl3', title: 'PHỤ LỤC 3: GIÁ DỊCH VỤ KỸ THUẬT, XÉT NGHIỆM', header: getPL3HeaderRow(isTYT), price: isTYT ? range(7, 17) : range(7, 16) },
    { name: 'PL4', key: 'pl4', title: 'PHỤ LỤC 4: GIÁ DỊCH VỤ KỸ THUẬT VÔ CẢM GÂY TÊ', header: getPL4HeaderRow(), price: range(7, 16) },
    { name: 'PL5', key: 'pl5', title: 'PHỤ LỤC 5: GIÁ DỊCH VỤ KỸ THUẬT CHẨN ĐOÁN HÌNH ẢNH SỬ DỤNG HỆ THỐNG PACS', header: getPL5HeaderRow(), price: range(6, 15) },
  ];
}

export async function buildReportWorkbook({ tenDonVi, timeFormatted, isTYT, rows }) {
  const wb = new ExcelJS.Workbook();
  for (const spec of sheetSpecs(isTYT)) {
    const ws = wb.addWorksheet(spec.name);
    const n = spec.header.length;
    ws.getCell('A1').value = `ĐƠN VỊ: ${String(tenDonVi).toUpperCase()}`;
    ws.getCell('A1').font = { bold: true, size: 11 };
    ws.getCell('A2').value = spec.title;
    ws.getCell('A2').font = { bold: true, size: 13, color: { argb: 'FF0369A1' } };
    ws.getCell('A3').value = `Thời gian ghi nhận: ${timeFormatted}`;
    ws.getCell('A3').font = { italic: true, size: 10, color: { argb: 'FF475569' } };
    const hr = ws.getRow(5);
    spec.header.forEach((h, i) => {
      const c = hr.getCell(i + 1);
      c.value = h;
      c.font = { bold: true, color: { argb: 'FF075985' } };
      c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0F2FE' } };
      c.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
    });
    hr.height = 48;
    const textCols = spec.key === 'pl3' || spec.key === 'pl4' ? [2, 4] : [2];
    (rows[spec.key] || []).forEach((src, ri) => {
      const row = ws.getRow(6 + ri);
      for (let i = 0; i < n; i++) {
        let v = src[i];
        if (v === undefined || v === null) v = '';
        if (textCols.includes(i + 1)) v = String(v).trim().replace(/^'+/, '');
        else if (spec.price.includes(i + 1) && v !== '') v = cleanNumberValue(v);
        const c = row.getCell(i + 1);
        c.value = v;
        if (textCols.includes(i + 1)) { c.numFmt = '@'; c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; }
        else if (spec.price.includes(i + 1)) { c.numFmt = '#,##0'; c.alignment = { vertical: 'middle' }; }
        else c.alignment = { vertical: 'middle', wrapText: true, horizontal: i === 0 ? 'center' : undefined };
      }
    });
    ws.columns.forEach((col, i) => { col.width = i === 0 ? 7 : (i === 1 || i === 4 || i === 5) ? 34 : 18; });
    ws.views = [{ state: 'frozen', ySplit: 5 }];
  }
  return wb;
}
