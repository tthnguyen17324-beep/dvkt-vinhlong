// Giao diện hệ thống - port từ Scripts.html (Apps Script). Logic nghiệp vụ giữ nguyên, thay google.script.run + Firebase bằng REST API.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const cleanKey = (s) => (s === undefined || s === null ? '' : String(s).trim().toLowerCase().replace(/^'+/, '').replace(/\s+/g, ' '));
const itemKey = (a, b) => { const c = cleanKey(a), k = cleanKey(b); return c ? `${c}_${k}` : k; };
const nl = (s) => esc(s).replace(/\n/g, '<br>');
function formatMoney(v) {
  if (v === '' || v === null || v === undefined) return '';
  const n = Number(v);
  return Number.isNaN(n) ? esc(v) : n.toLocaleString('vi-VN');
}

const FILE_TYPES = {
  QD_XepHangBV_hoac_QD_ThanhlapTYT: { input: 'fileHangBV', box: 'currentFileHangBV' },
  HoSo_MinhChungKhac: { input: 'fileMinhChungKhac', box: 'currentFileMinhChungKhac' },
  QD_PheDuyetDVKT: { input: 'filePheDuyetDVKT', box: 'currentFilePheDuyet' },
  QD_DuDieuKienKSK: { input: 'fileDuDieuKienKSK', box: 'currentFileKSK' },
};

const S = {
  cfg: {}, headers: null,
  auth: null,            // { ma, token }
  version: -1, files: [],
  sel: { pl1: {}, pl2: {}, pl3: {}, pl4: {}, pl5: {} },
  lists: { pl1: [], pl2: [], pl3Cache: {}, pl4: [], pl5: [], chapters: [], chapterMap: {} },
  loaded: { 2: false, 3: false, 4: false, 5: false, 7: false },
  step: 1, targetStep: 1, dirty: false, pl3Limit: 100, limits: { pl4: 200, pl5: 200 },
  adminPass: '', summary: [], metaApplied: false, locked: false, pending: 0, lastWrite: 0,
};

// ======================= API =======================
async function api(path, { method = 'GET', body, auth = false, admin = false, raw = false, form } = {}) {
  const headers = {};
  if (auth && S.auth) { headers['x-unit'] = S.auth.ma; headers['x-token'] = S.auth.token; }
  if (admin) headers['x-admin'] = S.adminPass;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch(path, { method, headers, body: payload });
  if (raw) return res;
  const data = await res.json().catch(() => ({ success: false, message: `Lỗi máy chủ (${res.status})` }));
  if (res.status === 429) return { success: false, message: 'Thao tác quá nhanh, vui lòng thử lại sau ít phút.' };
  return data;
}
async function download(path, opts, fallbackName) {
  const res = await api(path, { ...opts, raw: true });
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    showDialog('error', 'Không Tải Được', esc(j.message || 'Không thể tải tệp.'));
    return;
  }
  const cd = res.headers.get('content-disposition') || '';
  const m = /filename\*=UTF-8''([^;]+)/i.exec(cd);
  const name = m ? decodeURIComponent(m[1]) : fallbackName;
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ======================= Hộp thoại =======================
function showDialog(type, title, html, errorItems, onConfirm) {
  const badge = $('modalIconBadge'), ok = $('modalBtnOk'), cancel = $('modalBtnCancel');
  badge.className = 'modal-icon-badge';
  const T = {
    warning: ['badge-icon-warning', '⚠️', 'btn btn-warning', 'Đã hiểu', false],
    error: ['badge-icon-error', '❌', 'btn btn-danger', 'Đóng', false],
    success: ['badge-icon-success', '✅', 'btn btn-success', 'Đồng ý', false],
    confirm: ['badge-icon-confirm', '❓', 'btn btn-primary', 'Xác nhận gửi', true],
  }[type];
  badge.classList.add(T[0]); badge.textContent = T[1]; ok.className = T[2]; ok.textContent = T[3]; cancel.hidden = !T[4];
  $('modalTitle').textContent = title;
  $('modalDesc').innerHTML = html;
  const list = $('modalErrorList');
  list.hidden = !(errorItems && errorItems.length);
  list.innerHTML = (errorItems || []).map((i) => `<li>${i}</li>`).join('');
  ok.onclick = () => { closeDialog(); if (onConfirm) onConfirm(); };
  $('customAlertModal').hidden = false;
}
const closeDialog = () => { $('customAlertModal').hidden = true; };
$('modalBtnCancel').onclick = closeDialog;

// ======================= Điều hướng =======================
const markDirty = () => { S.dirty = true; };
function tryNavigate(step) {
  if (step === 6) { if (S.cfg.cpqlAppUrl) window.open(S.cfg.cpqlAppUrl, '_blank', 'noopener'); return; }
  S.targetStep = step;
  if (S.dirty) $('unsavedModal').hidden = false; else doNavigate(step);
}
function doNavigate(step) {
  document.querySelectorAll('.step-content').forEach((e) => e.classList.remove('active'));
  document.querySelectorAll('.step-item').forEach((e) => e.classList.remove('active'));
  S.step = step;
  $('step' + step).classList.add('active');
  for (let i = 1; i <= 7; i++) {
    const n = $('stepNode' + i);
    if (i === step) n.classList.add('active');
    if (i < step && i !== 6) n.classList.add('completed');
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (step === 2 && !S.loaded[2]) { loadPL1andPL2(); S.loaded[2] = true; }
  else if (step === 3 && !S.loaded[3]) { loadPL3Initial(); S.loaded[3] = true; }
  else if (step === 4 && !S.loaded[4]) { loadGeneric('pl4'); S.loaded[4] = true; }
  else if (step === 5 && !S.loaded[5]) { loadGeneric('pl5'); S.loaded[5] = true; }
  else if (step === 7 && !S.loaded[7]) { loadLookupHospitals(); S.loaded[7] = true; }
  renderSessionFiles();
}
document.addEventListener('click', (e) => {
  const go = e.target.closest('[data-go]'); if (go) return tryNavigate(Number(go.dataset.go));
  const st = e.target.closest('.step-item'); if (st) return tryNavigate(Number(st.dataset.step));
  const sv = e.target.closest('[data-save]'); if (sv) return saveDraft(Number(sv.dataset.save));
  const pw = e.target.closest('.pw-toggle');
  if (pw) { const i = $(pw.dataset.target); i.type = i.type === 'password' ? 'text' : 'password'; return; }
  const ex = e.target.closest('[data-excel]'); if (ex) return $('excelFile' + ex.dataset.excel.toUpperCase()).click();
  const all = e.target.closest('[data-all]'); if (all) return setAllGeneric(all.dataset.all, true);
  const none = e.target.closest('[data-none]'); if (none) return setAllGeneric(none.dataset.none, false);
  const fl = e.target.closest('[data-file]');
  if (fl) { e.preventDefault(); download(`/api/files/${fl.dataset.file}`, { auth: true }, fl.dataset.name || 'tep'); }
  const afl = e.target.closest('[data-afile]');
  if (afl) { e.preventDefault(); download(`/api/admin/files/${afl.dataset.afile}`, { admin: true }, afl.dataset.name || 'tep'); }
  const rep = e.target.closest('[data-report]');
  if (rep) { e.preventDefault(); download(`/api/export?id=${rep.dataset.report}`, { auth: true }, 'BaoCao_DVKT.xlsx'); }
  const drep = e.target.closest('[data-draftreport]');
  if (drep) { e.preventDefault(); download('/api/export?draft=1', { auth: true }, 'BaoCao_DVKT_luu_tam.xlsx'); }
  const arep = e.target.closest('[data-areport]');
  if (arep) { e.preventDefault(); download(`/api/admin/export/${arep.dataset.areport}`, { admin: true }, 'BaoCao_DVKT.xlsx'); }
  const unl = e.target.closest('[data-unlock]'); if (unl) unlockUnit(unl.dataset.unlock, unl.dataset.name);
});
$('btnUnsavedSave').onclick = () => { $('unsavedModal').hidden = true; saveDraft(S.step, () => doNavigate(S.targetStep)); };
$('btnUnsavedIgnore').onclick = () => { $('unsavedModal').hidden = true; S.dirty = false; doNavigate(S.targetStep); };
$('btnUnsavedStay').onclick = () => { $('unsavedModal').hidden = true; };

// ======================= Đơn vị & xác thực =======================
function populateHospitals(list) {
  const cur = $('maDonVi').value;
  $('maDonVi').innerHTML = '<option value="">-- Chọn đơn vị --</option>' +
    list.map((h) => `<option value="${esc(h.ma)}" data-email="${esc(h.email || '')}" ${h.ma === cur ? 'selected' : ''}>${esc(h.ten)}</option>`).join('');
}
async function loadHospitals() {
  const r = await api('/api/hospitals');
  if (r.success) populateHospitals(r.hospitals);
  else $('maDonVi').innerHTML = '<option value="">❌ Lỗi tải danh sách</option>';
}
$('btnRefreshHospitals').onclick = async (e) => {
  const b = e.currentTarget; b.textContent = '⏳'; await loadHospitals(); b.textContent = '🔄 Làm mới';
};
function resetLocal() {
  S.sel = { pl1: {}, pl2: {}, pl3: {}, pl4: {}, pl5: {} }; S.files = []; S.version = -1; S.metaApplied = false;
  renderFiles(); refreshAll();
}
$('maDonVi').onchange = () => {
  const o = $('maDonVi').selectedOptions[0];
  $('tenDonVi').value = o && o.value ? o.textContent : '';
  $('emailDonVi').value = o ? o.dataset.email || '' : '';
  S.auth = null; resetLocal();
  attach();
};
$('token').onblur = $('token').onchange = () => attach();
async function attach() {
  const ma = $('maDonVi').value.trim().toUpperCase(), token = $('token').value.trim();
  if (!ma || !token) { S.auth = null; return; }
  if (S.auth && S.auth.ma === ma && S.auth.token === token) return;
  const r = await api('/api/verify', { method: 'POST', body: { ma, token } });
  if (!r.isValid) {
    S.auth = null; resetLocal();
    showDialog('warning', 'Mã Xác Thực Không Đúng',
      `Mã xác thực (Token) không chính xác đối với đơn vị <strong>${esc($('maDonVi').selectedOptions[0]?.textContent || ma)}</strong>.<br>Hệ thống đã khóa dữ liệu để bảo mật.`);
    return;
  }
  S.auth = { ma, token };
  if (r.isLocked) showDialog('warning', 'Đơn Vị Đã Khóa', 'Đơn vị đã nộp báo cáo chính thức và đang ở trạng thái <strong>Đã khóa</strong>. Vui lòng liên hệ Sở Y tế để được mở khóa.');
  await loadState(true);
}

// ======================= Trạng thái đơn vị (đồng bộ) =======================
function applyMeta(meta) {
  if (!meta) return;
  const set = (id, v) => { const el = $(id); if (el && v !== undefined && v !== null && !el.value) el.value = v; };
  set('hoTen', meta.hoTen); set('khoaPhong', meta.khoaPhong); set('chucVu', meta.chucVu);
  set('soDienThoai', meta.soDienThoai); set('email', meta.emailThaoTac);
  if (meta.kskChecked !== undefined) { $('chkDuDieuKienKSK').checked = !!meta.kskChecked; toggleKSK(); }
}
async function loadState(first) {
  if (!S.auth) return;
  if (!first && S.pending > 0) return;
  const startedAt = Date.now();
  const r = await api(`/api/state${first ? '' : '?since=' + S.version}`, { auth: true });
  if (!r.success) { if (first) showDialog('error', 'Lỗi', esc(r.message)); return; }
  // Bỏ qua kết quả nếu trong lúc chờ có thao tác ghi của chính người dùng (tránh ghi đè bản mới hơn)
  if (!first && (S.pending > 0 || S.lastWrite >= startedAt - 50)) return;
  if (r.unchanged) return;
  S.version = r.version;
  S.sel = { pl1: {}, pl2: {}, pl3: {}, pl4: {}, pl5: {}, ...r.selections };
  S.files = r.files || []; S.locked = !!r.locked;
  if (!S.metaApplied) { applyMeta(r.meta); S.metaApplied = true; }
  const lh = r.meta && r.meta.loaiHinh;
  if (lh && $('loaiHinhCoSo').value !== lh) { $('loaiHinhCoSo').value = lh; invalidateCatalogs(); }
  renderFiles(); refreshAll();
}
setInterval(() => {
  if (S.auth && S.step <= 5 && !document.hidden && !document.activeElement?.closest?.('tbody input')) loadState(false);
}, 8000);

function refreshAll() {
  updateCounters(); renderChapterProgress();
  if (S.loaded[2]) { renderPL1(); renderPL2(); }
  if (S.loaded[3]) renderPL3Current();
  if (S.loaded[4]) renderGeneric('pl4');
  if (S.loaded[5]) renderGeneric('pl5');
}
function invalidateCatalogs() {
  S.loaded[2] = S.loaded[3] = false; S.lists.pl3Cache = {}; S.lists.chapterMap = {};
  if (S.step === 2 || S.step === 3) doNavigate(S.step);
}
$('loaiHinhCoSo').onchange = async () => {
  markDirty(); invalidateCatalogs();
  if (S.auth) await api('/api/meta', { method: 'PUT', auth: true, body: { loaiHinh: $('loaiHinhCoSo').value } });
};
const isTYT = () => $('loaiHinhCoSo').value === 'TYT';

// ======================= Hồ sơ đính kèm =======================
function renderFiles() {
  for (const [label, c] of Object.entries(FILE_TYPES)) {
    const f = S.files.find((x) => x.typeLabel === label);
    $(c.box).innerHTML = f ? `<div class="file-badge">✅ Đã nộp: <a data-file="${f.id}" data-name="${esc(f.name)}">${esc(f.name)}</a></div>` : '';
  }
  renderSessionFiles();
}
function renderSessionFiles() {
  const card = $('driveSessionCardStep5');
  const items = S.files.map((f) => `<li>📄 <a data-file="${f.id}" data-name="${esc(f.name)}">${esc(f.name)}</a></li>`);
  if (S.auth) items.push('<li>📊 <a data-draftreport="1">Tải Báo cáo giá DVKT (xem trước, .xlsx)</a></li>');
  card.hidden = !S.auth;
  $('driveFileListStep5').innerHTML = items.join('');
}
document.querySelectorAll('input[type=file][data-max]').forEach((inp) => {
  inp.addEventListener('change', () => {
    const f = inp.files[0]; if (!f) return;
    if (f.size > Number(inp.dataset.max) * 1048576) {
      showDialog('warning', 'Tệp Quá Lớn', `Tệp <strong>${esc(f.name)}</strong> vượt quá giới hạn <strong>${inp.dataset.max}MB</strong>. Vui lòng chọn tệp nhỏ hơn.`);
      inp.value = ''; inp.dataset.isNew = 'false'; return;
    }
    inp.dataset.isNew = 'true'; markDirty();
  });
});
function toggleKSK() {
  const on = $('chkDuDieuKienKSK').checked;
  $('cardUploadKSK').classList.toggle('file-disabled', !on);
  $('fileDuDieuKienKSK').disabled = !on; $('reqBadgeKSK').hidden = !on;
}
$('chkDuDieuKienKSK').onchange = () => { toggleKSK(); markDirty(); };
['hoTen', 'khoaPhong', 'chucVu', 'soDienThoai', 'email'].forEach((id) => $(id).addEventListener('input', markDirty));

// ======================= Phụ lục 1 & 2 =======================
function buildHead(id, headers, { numbered = true } = {}) {
  const th = headers.map((h, i) => `<th class="${i === 0 ? 'col-stt' : ''}">${nl(h)}</th>`);
  th.splice(1, 0, '<th class="col-act">Thực hiện</th>');
  $(id).innerHTML = `<tr>${th.join('')}</tr>`;
}
async function ensureHeaders() {
  if (!S.headers) {
    S.headers = await api('/api/headers');
    for (const k of ['pl1', 'pl2', 'pl3', 'pl4', 'pl5']) buildHead('headPL' + k.slice(2), S.headers[k]);
  }
}
async function loadPL1andPL2() {
  await ensureHeaders();
  const lh = $('loaiHinhCoSo').value;
  const [a, b] = await Promise.all([api('/api/catalog/pl1?lh=' + lh), api('/api/catalog/pl2?lh=' + lh)]);
  if (a.success) S.lists.pl1 = a.data;
  if (b.success) S.lists.pl2 = b.data;
  renderPL1(); renderPL2();
}
const toggleBtn = (on, attrs) => `<button type="button" class="btn-toggle ${on ? 'btn-yes' : 'btn-no'}" ${attrs}>${on ? 'Có' : 'Không'}</button>`;
function renderPL1() {
  $('bodyPL1').innerHTML = S.lists.pl1.map((it) => {
    if (it.isHeader) return `<tr class="header-row"><td colspan="14">${esc(it.ten)}</td></tr>`;
    const k = cleanKey(it.ten), s = S.sel.pl1[k], on = !!s;
    return `<tr><td class="col-stt"><strong>${esc(it.sttDisplay)}</strong></td><td class="col-act">${toggleBtn(on, `data-pl="pl1" data-key="${esc(k)}"`)}</td>
      <td class="col-pl1-name"><strong>${esc(it.ten)}</strong></td>
      ${[it.c3, it.c4, it.c5, it.c6, it.c7, it.c8, it.c9].map((v) => `<td class="cell-price">${formatMoney(v)}</td>`).join('')}
      <td class="cell-price" style="color:var(--primary-d);font-weight:700">${formatMoney(it.giaDeNghi)}</td>
      <td class="cell-price">${formatMoney(it.giaBHYT)}</td><td class="cell-price">${formatMoney(it.giaKhongBHYT)}</td>
      <td class="cell-note"><input type="text" value="${esc(s ? s.ghiChu : '')}" placeholder="Ghi chú đơn vị..." data-note-pl="pl1" data-key="${esc(k)}"></td></tr>`;
  }).join('');
}
function renderPL2() {
  $('bodyPL2').innerHTML = S.lists.pl2.map((it) => {
    if (it.isHeader || !it.hasAction) return `<tr class="header-row"><td class="col-stt"><strong>${esc(it.sttDisplay)}</strong></td><td class="col-act">-</td><td colspan="13">${esc(it.ten)}</td></tr>`;
    const k = cleanKey(it.ten), s = S.sel.pl2[k], on = !!s;
    return `<tr><td class="col-stt"><strong>${esc(it.sttDisplay)}</strong></td><td class="col-act">${toggleBtn(on, `data-pl="pl2" data-key="${esc(k)}"`)}</td>
      <td class="col-pl1-name"><strong>${esc(it.ten)}</strong></td>
      ${[it.c3, it.c4, it.c5, it.c6, it.c7, it.c8, it.c9, it.c10].map((v) => `<td class="cell-price">${formatMoney(v)}</td>`).join('')}
      <td class="cell-price" style="color:var(--primary-d);font-weight:700">${formatMoney(it.giaDeNghi)}</td>
      <td class="cell-price">${formatMoney(it.giaBHYT)}</td><td class="cell-price">${formatMoney(it.giaKhongBHYT)}</td>
      <td class="cell-note"><input type="text" value="${esc(s ? s.ghiChu : '')}" placeholder="Ghi chú đơn vị..." data-note-pl="pl2" data-key="${esc(k)}"></td></tr>`;
  }).join('');
}

// ======================= Chọn / ghi chú (dùng chung) =======================
async function pushSelections(pl, items, opts = {}) {
  if (!S.auth) return false;
  S.pending++;
  try {
    const r = await api('/api/selections', { method: 'PUT', auth: true, body: { pl, items, ...opts } });
    if (!r.success) { showDialog('error', 'Lỗi Lưu Lựa Chọn', esc(r.message)); return false; }
    return true;
  } finally { S.pending--; S.lastWrite = Date.now(); }
}
function needAuth() {
  if (S.auth) return false;
  showDialog('warning', 'Thiếu Thông Tin Xác Thực', 'Vui lòng chọn <strong>Tên đơn vị</strong> và nhập <strong>Mã xác thực (Token)</strong> ở Trang 1 trước khi chọn dịch vụ!');
  return true;
}
function chapterOfPL3() { return $('selectChuongPL3').value; }
async function toggleItem(pl, key, btn) {
  if (needAuth()) return;
  markDirty();
  const on = !S.sel[pl][key];
  const old = S.sel[pl][key];
  const note = on ? (btn.closest('tr')?.querySelector('input[data-note-pl]')?.value || '') : '';
  if (on) S.sel[pl][key] = { tichChon: true, ghiChu: note, ...(pl === 'pl3' ? { chuong: chapterOfPL3() } : {}) }; else delete S.sel[pl][key];
  btn.className = `btn-toggle ${on ? 'btn-yes' : 'btn-no'}`; btn.textContent = on ? 'Có' : 'Không';
  updateCounters(); renderChapterProgress();
  const ok = await pushSelections(pl, [{ key, tichChon: on, ghiChu: note, chuong: pl === 'pl3' ? chapterOfPL3() : '' }]);
  if (!ok) { if (old) S.sel[pl][key] = old; else delete S.sel[pl][key]; refreshAll(); }
}
async function noteItem(pl, key, value) {
  if (needAuth()) return;
  markDirty();
  const cur = S.sel[pl][key];
  if (!cur) return; // chỉ lưu ghi chú khi dịch vụ đã được chọn (giống file xuất)
  cur.ghiChu = value;
  await pushSelections(pl, [{ key, tichChon: true, ghiChu: value, chuong: pl === 'pl3' ? cur.chuong || chapterOfPL3() : '' }]);
}
for (const id of ['bodyPL1', 'bodyPL2', 'bodyPL3', 'bodyPL4', 'bodyPL5']) {
  $(id).addEventListener('click', (e) => {
    const b = e.target.closest('button[data-pl]'); if (b) toggleItem(b.dataset.pl, b.dataset.key, b);
    const m = e.target.closest('button[data-more]'); if (m) loadMore(m.dataset.more);
  });
  $(id).addEventListener('change', (e) => {
    const i = e.target.closest('input[data-note-pl]'); if (i) noteItem(i.dataset.notePl, i.dataset.key, i.value);
  });
}
function loadMore(pl) {
  if (pl === 'pl3') { S.pl3Limit += 100; renderPL3Current(); } else { S.limits[pl] += 200; renderGeneric(pl); }
}

// ======================= Phụ lục 3 =======================
async function loadPL3Initial() {
  await ensureHeaders();
  const sel = $('selectChuongPL3');
  sel.innerHTML = '<option value="">⏳ Đang nạp danh mục Chương...</option>';
  const t = isTYT() ? 1 : 0;
  const chapters = await fetch('/api/catalog/pl3/chapters?tyt=' + t).then((r) => r.json());
  S.lists.chapters = chapters || [];
  if (!chapters.length) { sel.innerHTML = '<option value="">Không có dữ liệu chương</option>'; return; }
  sel.innerHTML = chapters.map((c) => `<option value="${esc(c.name)}">${esc(c.name)} (${c.count} DV)</option>`).join('');
  fetch('/api/catalog/pl3/chapter-map?tyt=' + t).then((r) => r.json()).then((m) => { S.lists.chapterMap = m || {}; updateCounters(); renderChapterProgress(); });
  loadPL3Chapter(chapters[0].name);
}
$('selectChuongPL3').onchange = () => { S.pl3Limit = 100; loadPL3Chapter(chapterOfPL3()); };
async function loadPL3Chapter(ch) {
  const tb = $('bodyPL3');
  if (S.lists.pl3Cache[ch]) return renderPL3(S.lists.pl3Cache[ch]);
  tb.innerHTML = '<tr><td colspan="20" class="center">⏳ Đang tải kỹ thuật của chương...</td></tr>';
  const r = await fetch(`/api/catalog/pl3/chapter?tyt=${isTYT() ? 1 : 0}&name=${encodeURIComponent(ch)}`).then((x) => x.json());
  if (!r.success) { tb.innerHTML = `<tr><td colspan="20" class="center" style="color:red">${esc(r.message)}</td></tr>`; return; }
  S.lists.pl3Cache[ch] = r.data; renderPL3(r.data);
}
const renderPL3Current = () => { const c = S.lists.pl3Cache[chapterOfPL3()]; if (c) renderPL3(c); };
function renderPL3(items) {
  const search = $('searchPL3').value.toLowerCase().trim(), onlyCo = $('chkOnlyCoPL3').checked, tyt = isTYT();
  const filtered = items.filter((it) => {
    const k = itemKey(it.maDungChung, it.maKyThuat);
    if (onlyCo && !S.sel.pl3[k]) return false;
    if (search) return [it.maKyThuat, it.tenKyThuat, it.tenPheDuyet].some((v) => String(v).toLowerCase().includes(search));
    return true;
  });
  const tb = $('bodyPL3');
  if (!filtered.length) { tb.innerHTML = '<tr><td colspan="20" class="center" style="color:#888">Không có dịch vụ phù hợp.</td></tr>'; return; }
  let stt = 1;
  let html = filtered.slice(0, S.pl3Limit).map((it) => {
    const k = itemKey(it.maDungChung, it.maKyThuat), s = S.sel.pl3[k], r = it.rowValues;
    return `<tr><td class="col-stt"><strong>${stt++}</strong></td><td class="col-act">${toggleBtn(!!s, `data-pl="pl3" data-key="${esc(k)}"`)}</td>
      <td class="col-pl3-3">${esc(r[1])}</td><td class="col-pl3-4">${esc(r[2])}</td><td class="col-pl3-5"><strong>${esc(it.maKyThuat)}</strong></td>
      <td class="col-pl3-6"><strong>${esc(it.tenKyThuat)}</strong></td><td class="col-pl3-7" style="color:#0056b3">${esc(it.tenPheDuyet)}</td>
      ${[6, 7, 8, 9, 10, 11, 12].map((i) => `<td class="cell-price">${formatMoney(r[i])}</td>`).join('')}
      <td class="cell-price" style="color:#d63384">${tyt ? formatMoney(r[13]) : '-'}</td>
      <td class="cell-price" style="color:var(--primary-d);font-weight:700">${formatMoney(it.giaDeNghi)}</td>
      <td class="cell-price">${formatMoney(tyt ? r[15] : r[14])}</td><td class="cell-price">${formatMoney(tyt ? r[16] : r[15])}</td>
      <td style="font-size:12px;color:#475569;min-width:120px">${esc(tyt ? r[17] : r[16])}</td>
      <td class="cell-note"><input type="text" value="${esc(s ? s.ghiChu : '')}" placeholder="Ghi chú đơn vị..." data-note-pl="pl3" data-key="${esc(k)}"></td></tr>`;
  }).join('');
  if (filtered.length > S.pl3Limit) html += `<tr><td colspan="20" class="center" style="padding:12px"><button type="button" class="btn btn-primary" data-more="pl3">Hiển thị thêm 100 dịch vụ tiếp theo (Còn ${filtered.length - S.pl3Limit} DV) ⏬</button></td></tr>`;
  tb.innerHTML = html;
}
$('searchPL3').oninput = renderPL3Current; $('chkOnlyCoPL3').onchange = renderPL3Current;
$('btnAllPL3').onclick = () => setAllPL3(true); $('btnNonePL3').onclick = () => setAllPL3(false);
async function setAllPL3(status) {
  if (needAuth()) return;
  const ch = chapterOfPL3(), items = S.lists.pl3Cache[ch]; if (!ch || !items) return;
  markDirty();
  const batch = items.map((it) => ({ key: itemKey(it.maDungChung, it.maKyThuat), tichChon: status, ghiChu: '', chuong: ch }));
  for (const b of batch) {
    if (status) { if (!S.sel.pl3[b.key]) S.sel.pl3[b.key] = { tichChon: true, ghiChu: '', chuong: ch }; } else delete S.sel.pl3[b.key];
  }
  renderPL3Current(); updateCounters(); renderChapterProgress();
  await pushSelections('pl3', batch);
}

// ======================= Phụ lục 4 & 5 =======================
async function loadGeneric(pl) {
  await ensureHeaders();
  $('body' + pl.toUpperCase()).innerHTML = '<tr><td colspan="20" class="center">⏳ Đang tải danh mục...</td></tr>';
  const r = await fetch('/api/catalog/' + pl).then((x) => x.json());
  if (r.success) S.lists[pl] = r.data;
  renderGeneric(pl);
}
function renderGeneric(pl) {
  const P = pl.toUpperCase(), search = $('search' + P).value.toLowerCase().trim(), onlyCo = $('chkOnlyCo' + P).checked;
  const filtered = S.lists[pl].filter((it) => {
    const k = itemKey(it.rowValues[1], it.rowValues[3]);
    if (onlyCo && !S.sel[pl][k]) return false;
    if (search) return [it.maKyThuat, it.tenKyThuat, it.rowValues[1], it.rowValues[5]].some((v) => String(v ?? '').toLowerCase().includes(search));
    return true;
  });
  const tb = $('body' + P);
  if (!filtered.length) { tb.innerHTML = '<tr><td colspan="20" class="center" style="color:#888">Không có dịch vụ phù hợp.</td></tr>'; return; }
  const textIdx = pl === 'pl4' ? [1, 2, 3, 4, 5, 16] : [1, 2, 3, 4, 15];
  const last = pl === 'pl4' ? 16 : 15;
  let stt = 1;
  const lim = S.limits[pl];
  let html = filtered.slice(0, lim).map((it) => {
    const r = it.rowValues, k = itemKey(r[1], r[3]), s = S.sel[pl][k];
    let tds = '';
    for (let i = 1; i <= last; i++) {
      tds += textIdx.includes(i) ? `<td ${i === 3 && pl === 'pl4' ? '' : ''}>${i === 1 || i === 3 ? '<strong>' + esc(r[i]) + '</strong>' : esc(r[i])}</td>` : `<td class="cell-price">${formatMoney(r[i])}</td>`;
    }
    return `<tr><td class="col-stt"><strong>${stt++}</strong></td><td class="col-act">${toggleBtn(!!s, `data-pl="${pl}" data-key="${esc(k)}"`)}</td>${tds}
      <td class="cell-note"><input type="text" value="${esc(s ? s.ghiChu : '')}" placeholder="Ghi chú đơn vị..." data-note-pl="${pl}" data-key="${esc(k)}"></td></tr>`;
  }).join('');
  if (filtered.length > lim) html += `<tr><td colspan="20" class="center" style="padding:12px"><button type="button" class="btn btn-primary" data-more="${pl}">Hiển thị thêm 200 dịch vụ (Còn ${filtered.length - lim} DV) ⏬</button></td></tr>`;
  tb.innerHTML = html;
}
for (const pl of ['pl4', 'pl5']) {
  const P = pl.toUpperCase();
  $('search' + P).oninput = () => { S.limits[pl] = 200; renderGeneric(pl); };
  $('chkOnlyCo' + P).onchange = () => renderGeneric(pl);
}
async function setAllGeneric(pl, status) {
  if (needAuth()) return;
  markDirty();
  const batch = S.lists[pl].map((it) => ({ key: itemKey(it.rowValues[1], it.rowValues[3]), tichChon: status, ghiChu: '' }));
  for (const b of batch) { if (status) { if (!S.sel[pl][b.key]) S.sel[pl][b.key] = { tichChon: true, ghiChu: '' }; } else delete S.sel[pl][b.key]; }
  renderGeneric(pl); updateCounters();
  await pushSelections(pl, batch);
}

// ======================= Nhập từ Excel =======================
for (const pl of ['pl3', 'pl4', 'pl5']) $('excelFile' + pl.toUpperCase()).onchange = (e) => importExcel(pl, e);
function importExcel(pl, e) {
  const file = e.target.files[0]; if (!file) return;
  if (needAuth()) { e.target.value = ''; return; }
  showDialog('confirm', 'Đang Xử Lý', '⏳ Hệ thống đang đọc file Excel và đối chiếu danh mục kỹ thuật, vui lòng chờ...');
  const reader = new FileReader();
  reader.onload = async (evt) => {
    try {
      const wb = XLSX.read(new Uint8Array(evt.target.result), { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false });
      if (!rows || rows.length <= 1) { closeDialog(); return showDialog('warning', 'File Rỗng', 'File Excel không có dữ liệu nội dung!'); }
      let cMC = -1, cKT = -1, cCh = -1, cGC = -1, start = 0;
      for (let r = 0; r < Math.min(rows.length, 15); r++) {
        const row = rows[r]; if (!row) continue;
        for (let c = 0; c < row.length; c++) {
          const v = cleanKey(row[c]);
          if (v.includes('dùng chung') || v.includes('ma dung chung') || v.includes('mã c')) cMC = c;
          if (v.includes('mã kỹ thuật') || v.includes('ma ky thuat') || v.includes('mã kt') || v.includes('23/2024')) cKT = c;
          if (v.includes('chương') || v.includes('chuong')) cCh = c;
          if (v.includes('ghi chú') || v.includes('ghichu') || v.includes('note')) cGC = c;
        }
        if (cKT !== -1 || cMC !== -1) { start = r + 1; break; }
      }
      if (cKT === -1 && cMC === -1) { cMC = 1; cCh = 2; cKT = pl === 'pl5' ? -1 : 3; start = 1; }
      const entries = [];
      for (let i = start; i < rows.length; i++) {
        const r = rows[i]; if (!r || !r.length) continue;
        const mC = cMC !== -1 ? String(r[cMC] || '').trim() : '', mKT = cKT !== -1 ? String(r[cKT] || '').trim() : '';
        if (mC || mKT) entries.push({ maChung: mC, maKT: mKT, chuong: cCh !== -1 ? String(r[cCh] || '').trim() : '', note: cGC !== -1 ? String(r[cGC] || '').trim() : '' });
      }
      if (!entries.length) { closeDialog(); return showDialog('warning', 'Không Có Dữ Liệu', 'Không tìm thấy cột Mã dịch vụ trong file Excel!'); }
      const res = await api('/api/match-excel', { method: 'POST', body: { pl, isTYT: isTYT(), entries } });
      closeDialog();
      if (!res.success) return showDialog('error', 'Lỗi Đối Chiếu', esc(res.message || 'Lỗi xử lý máy chủ.'));
      if (!res.list.length) return showDialog('warning', 'Không Tìm Thấy Mã Phù Hợp', `Không có dịch vụ kỹ thuật nào trong file khớp với danh mục <strong>${pl.toUpperCase()}</strong>.<br>Vui lòng kiểm tra lại cột mã kỹ thuật hoặc mã dùng chung.`);
      for (const it of res.list) S.sel[pl][it.uniqueKey] = { tichChon: true, ghiChu: it.ghiChu, ...(pl === 'pl3' ? { chuong: it.chuong } : {}) };
      await pushSelections(pl, res.list.map((it) => ({ key: it.uniqueKey, tichChon: true, ghiChu: it.ghiChu, chuong: it.chuong })));
      markDirty(); refreshAll();
      showDialog('success', 'Nhập Dữ Liệu Thành Công', `Đã đối chiếu thành công và tự động tích chọn <strong>${res.list.length}</strong> dịch vụ kỹ thuật cho <strong>${pl.toUpperCase()}</strong>!`);
    } catch (err) {
      closeDialog(); showDialog('error', 'Lỗi Đọc File', 'Không thể đọc file: ' + esc(err.message));
    } finally { e.target.value = ''; }
  };
  reader.readAsArrayBuffer(file);
}

// ======================= Tiến độ =======================
function updateCounters() {
  const n = (pl) => Object.keys(S.sel[pl] || {}).length;
  ['pl1', 'pl2', 'pl3', 'pl4', 'pl5'].forEach((p, i) => { $('statPL' + (i + 1)).textContent = n(p).toLocaleString('vi-VN'); });
  $('statTotal').textContent = (n('pl1') + n('pl2') + n('pl3') + n('pl4') + n('pl5')).toLocaleString('vi-VN');
}
function renderChapterProgress() {
  const box = $('chapterProgressBar');
  if (!S.lists.chapters.length) { box.innerHTML = ''; return; }
  const per = {};
  for (const [k, v] of Object.entries(S.sel.pl3)) {
    const ch = S.lists.chapterMap[k] || v.chuong || '';
    if (ch) per[cleanKey(ch)] = (per[cleanKey(ch)] || 0) + 1;
  }
  box.innerHTML = S.lists.chapters.map((c) => {
    const n = per[cleanKey(c.name)] || 0;
    return `<span class="ch-chip ${n ? 'has' : ''}">${esc(c.name)}: ${n}/${c.count}</span>`;
  }).join('');
}

// ======================= Lưu & Nộp =======================
function metaPayload() {
  return {
    loaiHinh: $('loaiHinhCoSo').value, hoTen: $('hoTen').value, khoaPhong: $('khoaPhong').value, chucVu: $('chucVu').value,
    soDienThoai: $('soDienThoai').value, emailThaoTac: $('email').value.trim(), kskChecked: $('chkDuDieuKienKSK').checked,
  };
}
async function uploadNewFiles() {
  for (const [label, c] of Object.entries(FILE_TYPES)) {
    const inp = $(c.input);
    if (!inp.files.length || inp.dataset.isNew !== 'true') continue;
    if (label === 'QD_DuDieuKienKSK' && !$('chkDuDieuKienKSK').checked) continue;
    const form = new FormData(); form.append('typeLabel', label); form.append('file', inp.files[0]);
    const r = await api('/api/files', { method: 'POST', auth: true, form });
    if (!r.success) throw new Error(r.message);
    S.files = r.files; inp.dataset.isNew = 'false'; inp.value = '';
  }
  renderFiles();
}
async function saveDraft(page, cb) {
  if (!$('maDonVi').value || !$('token').value) return showDialog('warning', 'Thiếu Thông Tin Xác Thực', 'Vui lòng chọn <strong>Tên đơn vị</strong> và nhập <strong>Mã xác thực (Token)</strong> trước khi bấm Lưu!');
  await attach();
  if (!S.auth) return;
  const btns = document.querySelectorAll('.btn-success[data-save]');
  btns.forEach((b) => { b.dataset.old = b.textContent; b.textContent = '⏳ Đang lưu...'; b.disabled = true; });
  const restore = () => btns.forEach((b) => { b.textContent = b.dataset.old || '💾 Lưu'; b.disabled = false; });
  try {
    await uploadNewFiles();
    const r = await api('/api/save', { method: 'POST', auth: true, body: { ...metaPayload(), isFinalSubmit: false } });
    restore();
    if (!r.success) return showDialog('error', 'Lỗi Lưu Tạm', esc(r.message));
    S.dirty = false; S.files = r.files || S.files; renderFiles(); await loadState(true);
    if (page === 1) showDialog('success', 'Đã Khởi Tạo Thư Mục Lưu Tạm', 'Đã tạo thư mục lưu tạm thành công trên hệ thống.<br>Toàn bộ hồ sơ đính kèm và dữ liệu các bước tiếp theo sẽ được lưu trữ đồng bộ vào thư mục này.');
    else showDialog('success', 'Lưu Thành Công', 'Dữ liệu đã được đồng bộ và lưu tạm trên hệ thống!');
    if (cb) cb();
  } catch (err) { restore(); showDialog('error', 'Lỗi Lưu Tạm', esc(err.message)); }
}
$('btnFinalSubmit').onclick = async () => {
  const v = (id) => $(id).value.trim();
  const miss = [];
  if (!$('maDonVi').value) miss.push('Chưa chọn <strong>Tên Đơn vị</strong>.');
  if (!v('token')) miss.push('Chưa nhập <strong>Mã xác thực (Token)</strong>.');
  if (!v('hoTen')) miss.push('Chưa nhập <strong>Họ và tên người thực hiện</strong>.');
  if (!v('khoaPhong')) miss.push('Chưa nhập <strong>Khoa / Phòng</strong>.');
  if (!v('chucVu')) miss.push('Chưa nhập <strong>Chức vụ</strong>.');
  if (!v('soDienThoai')) miss.push('Chưa nhập <strong>Số điện thoại liên hệ</strong>.');
  if (!v('email')) miss.push('Chưa nhập <strong>Email liên hệ</strong>.');
  const has = (label) => $(FILE_TYPES[label].input).files.length > 0 || S.files.some((f) => f.typeLabel === label);
  const ksk = $('chkDuDieuKienKSK').checked;
  if (!has('QD_XepHangBV_hoac_QD_ThanhlapTYT')) miss.push('Thiếu: <strong>Quyết định xếp hạng Bệnh viện / Quyết định thành lập Trạm Y tế (*)</strong> (Trang 1).');
  if (!has('QD_PheDuyetDVKT')) miss.push('Thiếu: <strong>Quyết định phê duyệt dịch vụ kỹ thuật (*)</strong> (Trang 2).');
  if (ksk && !has('QD_DuDieuKienKSK')) miss.push('Đơn vị đã tích chọn đủ điều kiện khám sức khỏe nhưng chưa đính kèm: <strong>Quyết định / Thông báo đủ điều kiện khám sức khỏe (*)</strong> (Trang 2).');
  if (miss.length) return showDialog('warning', 'CẢNH BÁO THIẾU HỒ SƠ BẮT BUỘC', 'Hồ sơ báo cáo chưa đầy đủ. Vui lòng bổ sung các nội dung sau trước khi gửi:', miss);
  await attach(); if (!S.auth) return;
  const total = $('statTotal').textContent;
  showDialog('confirm', 'XÁC NHẬN GỬI BÁO CÁO CHÍNH THỨC',
    `<p>Đơn vị đã chọn đề xuất: <strong style="color:#059669;font-size:16px">${esc(total)}</strong> dịch vụ.</p>
     <p>Sau khi gửi thành công, đơn vị sẽ <strong>CHUYỂN SANG TRẠNG THÁI KHÓA</strong> để Hội đồng tổng hợp.</p>
     <p style="color:#0284c7"><em>Quý đơn vị có thể mở mục Tra cứu để xem lại báo cáo và hồ sơ bất kỳ lúc nào.</em></p>`, null, async () => {
      const btn = $('btnFinalSubmit'); btn.disabled = true; btn.textContent = '⏳ Đang xử lý nộp báo cáo...';
      try {
        await uploadNewFiles();
        const r = await api('/api/save', { method: 'POST', auth: true, body: { ...metaPayload(), isFinalSubmit: true } });
        if (r.success) showDialog('success', 'Nộp Báo Cáo Thành Công', esc(r.message).replace(/\n/g, '<br>'), null, () => location.reload());
        else { showDialog('error', 'Lỗi Nộp Báo Cáo', esc(r.message)); btn.disabled = false; btn.textContent = '🚀 GỬI BÁO CÁO CHÍNH THỨC'; }
      } catch (err) { showDialog('error', 'Lỗi Nộp Báo Cáo', esc(err.message)); btn.disabled = false; btn.textContent = '🚀 GỬI BÁO CÁO CHÍNH THỨC'; }
    });
};

// ======================= Khôi phục =======================
$('btnRestoreDraft').onclick = async () => {
  if (!$('maDonVi').value || !$('token').value) return showDialog('warning', 'Thiếu Thông Tin Xác Thực', 'Vui lòng chọn <strong>Tên đơn vị</strong> và nhập <strong>Mã xác thực (Token)</strong> trước!');
  await attach(); if (!S.auth) return;
  await loadState(true);
  const total = Object.values(S.sel).reduce((a, b) => a + Object.keys(b).length, 0);
  showDialog('success', 'Đã Tải Lại Bản Lưu Tạm', `Đã khôi phục dữ liệu lưu tạm của đơn vị: <strong>${total.toLocaleString('vi-VN')}</strong> dịch vụ đã chọn.`);
};
$('btnOpenSessions').onclick = async () => {
  if (!$('maDonVi').value || !$('token').value) return showDialog('warning', 'Thiếu Thông Tin Xác Thực', 'Vui lòng chọn <strong>Tên đơn vị</strong> và nhập <strong>Mã xác thực (Token)</strong> trước!');
  await attach(); if (!S.auth) return;
  const r = await api('/api/sessions', { auth: true });
  if (!r.success) return showDialog('error', 'Lỗi', esc(r.message));
  if (!r.list.length) return showDialog('warning', 'Chưa Có Phiên', 'Đơn vị chưa có phiên báo cáo nào đã gửi.');
  $('selectSubmittedSessions').innerHTML = r.list.map((s) =>
    `<option value="${s.id}">${esc(s.timeFormatted)} - ${esc(s.hoTen)} (${esc(s.status)})${s.hasSnapshot ? '' : ' - chỉ có liên kết cũ'}</option>`).join('');
  $('sessionHistoryBox').hidden = false;
};
$('btnLoadSession').onclick = async () => {
  const id = $('selectSubmittedSessions').value; if (!id) return;
  const r = await api('/api/restore', { method: 'POST', auth: true, body: { id: Number(id) } });
  if (!r.success) return showDialog(r.isNewSession ? 'warning' : 'error', 'Không Khôi Phục Được', esc(r.message));
  if (r.loaiHinh) $('loaiHinhCoSo').value = r.loaiHinh;
  invalidateCatalogs(); await loadState(true); S.dirty = false;
  showDialog('success', 'Khôi Phục Thành Công', `Đã tải lại <strong>${r.counts.total.toLocaleString('vi-VN')}</strong> dịch vụ của phiên đã chọn. Bạn có thể chỉnh sửa và gửi lại.`);
};

// ======================= Tra cứu =======================
async function loadLookupHospitals() {
  const sel = $('lookupDonVi'); sel.innerHTML = '<option value="">-- Đang tải danh sách đầy đủ --</option>';
  const r = await api('/api/lookup-hospitals');
  sel.innerHTML = '<option value="">-- Chọn đơn vị --</option>' + (r.hospitals || []).map((h) => `<option value="${esc(h.ma)}">${esc(h.ten)}</option>`).join('');
}
$('btnRefreshLookup').onclick = loadLookupHospitals;
$('btnLookup').onclick = async (e) => {
  const btn = e.currentTarget, ma = $('lookupDonVi').value.trim().toUpperCase(), token = $('lookupToken').value.trim();
  if (!ma || !token) return showDialog('warning', 'Thiếu Thông Tin', 'Vui lòng chọn <strong>Tên đơn vị</strong> và nhập <strong>Mã xác thực (Token)</strong> để tra cứu!');
  const old = btn.innerHTML; btn.innerHTML = '⏳ Đang tra cứu...'; btn.disabled = true;
  const saved = S.auth; S.auth = { ma, token };
  const r = await api('/api/lookup', { auth: true });
  S.auth = saved; btn.innerHTML = old; btn.disabled = false;
  if (!r.success) { $('lookupResultBox').hidden = true; return showDialog('warning', 'Không Có Dữ Liệu', esc(r.message)); }
  const c = r.counts || {}, x = (v) => (v ? '<span class="badge-x">X</span>' : '<span style="color:#94a3b8">-</span>'), nf = (v) => (v || 0).toLocaleString('vi-VN');
  $('lookupDetailInfo').innerHTML = `
    <div class="info-grid">
      <div><strong>Tên đơn vị:</strong> <b style="color:#0369a1">${esc(r.tenDonVi)}</b> (${esc(ma)})</div>
      <div><strong>Thời gian gửi phiên cuối:</strong> <b style="color:#059669">${esc(r.timeFormatted)}</b></div>
      <div><strong>Người nộp/người đầu mối phụ trách:</strong> ${esc(r.hoTen || 'Chưa rõ')} (${esc(r.chucVu || '')} - ${esc(r.khoaPhong || '')})</div>
      <div><strong>Số điện thoại:</strong> ${esc(r.soDienThoai || 'Chưa cập nhật')}</div>
      <div><strong>Email liên hệ:</strong> ${esc(r.email || 'Chưa cập nhật')}</div>
      <div><strong>Trạng thái hồ sơ:</strong> <span class="status-pill ${r.isLocked ? 'status-locked' : 'status-open'}">${r.isLocked ? '🔒' : '🔓'} ${esc(r.status)}</span></div>
    </div>
    ${r.noiDungYeuCauBoSung ? `<div class="info-block" style="background:#fef2f2;border-color:#fecaca;color:#991b1b"><strong>⚠️ Nội dung yêu cầu đơn vị bổ sung (Nghiệp vụ Y):</strong><br>${esc(r.noiDungYeuCauBoSung)}</div>` : ''}
    ${r.ketQuaBoSung ? `<div class="info-block" style="background:#eff6ff;border-color:#bfdbfe;color:#1e40af"><strong>📝 Kết quả bổ sung của đơn vị:</strong><br>${esc(r.ketQuaBoSung)}</div>` : ''}
    <div class="info-block"><div style="font-weight:700;color:#0369a1;margin-bottom:6px">PHỤ LỤC 1 (ĐÁNH DẤU X LÀ CÓ):</div>
      <div class="info-grid" style="font-size:12.5px">
        <div>• Khám bệnh: ${x(c.pl1_kb)}</div>
        <div>• Hội chẩn để xác định ca bệnh khó (chuyên gia/ca; Chỉ áp dụng đối với trường hợp mời chuyên gia đơn vị khác đến hội chẩn tại cơ sở khám, chữa bệnh): ${x(c.pl1_hc)}</div>
        <div>• Khám cấp giấy chứng thương, giám định y khoa (không kể xét nghiệm, X-quang): ${x(c.pl1_gd)}</div>
        <div>• Khám sức khỏe toàn diện lao động, lái xe, khám sức khỏe định kỳ (không kể xét nghiệm, X-quang): ${x(c.pl1_skld)}</div>
        <div>• Khám sức khỏe toàn diện cho người đi xuất khẩu lao động (không kể xét nghiệm, X-quang): ${x(c.pl1_xkd)}</div>
      </div></div>
    <div class="info-block" style="background:#f0fdf4;border-color:#bbf7d0;display:flex;gap:16px;flex-wrap:wrap">
      <div><strong>Phụ lục 2:</strong> <b style="color:#0369a1">${nf(c.c2)}</b></div><div><strong>Phụ lục 3:</strong> <b style="color:#0369a1">${nf(c.c3)}</b></div>
      <div><strong>Phụ lục 4:</strong> <b style="color:#0369a1">${nf(c.c4)}</b></div><div><strong>Phụ lục 5:</strong> <b style="color:#0369a1">${nf(c.c5)}</b></div>
      <div><strong>Tổng KT (PL3+PL4+PL5):</strong> <b style="color:#059669">${nf(c.totalKT)}</b></div></div>`;
  let links = '';
  if (r.hasSnapshot) {
    S.auth = { ma, token };
    links += `<div class="link-card">📊 <strong>BÁO CÁO GIÁ DVKT (PHIÊN [${esc(r.timeFormatted)}]):</strong><br>` +
      (r.sheetUrl ? `<a href="${esc(r.sheetUrl)}" target="_blank" rel="noopener">👉 Mở xem Bảng tính Google Sheet Báo cáo giá DVKT của đơn vị ↗</a><br>` : '') +
      `<button class="as-link" data-lookup-report="${r.submissionId}">👉 Tải Báo cáo giá DVKT của đơn vị (.xlsx) ⬇</button></div>`;
    S.auth = saved;
  } else if (r.folderUrl) {
    links += `<div class="link-card">📊 <strong>HỒ SƠ PHIÊN CŨ:</strong><br><a href="${esc(r.folderUrl)}" target="_blank" rel="noopener">👉 Mở thư mục Google Drive của phiên (dữ liệu trước khi chuyển hệ thống) ↗</a></div>`;
  }
  links += r.thuyetMinhCPQLSheetUrl && r.thuyetMinhCPQLSheetUrl.startsWith('http')
    ? `<div class="link-card cpql">📑 <strong>BÁO CÁO THUYẾT MINH CHI PHÍ QUẢN LÝ:</strong><br><a href="${esc(r.thuyetMinhCPQLSheetUrl)}" target="_blank" rel="noopener">👉 Mở xem Bảng tính Thuyết minh Chi phí quản lý của đơn vị ↗</a></div>`
    : '<div class="link-card empty">📑 <strong>Thuyết minh chi phí quản lý:</strong> Chưa có dữ liệu liên kết báo cáo của đơn vị.</div>';
  if (r.attachedFiles && r.attachedFiles.length) {
    links += `<div style="margin-top:14px"><strong>📎 DANH SÁCH CÁC TỆP ĐÍNH KÈM ĐÃ NỘP CỦA PHIÊN:</strong><ul class="file-list" style="padding-left:20px;list-style:disc">` +
      r.attachedFiles.map((f) => `<li>📄 <a data-lookup-file="${f.id}" data-name="${esc(f.name)}">${esc(f.name)}</a></li>`).join('') + '</ul></div>';
  }
  $('lookupLinksArea').innerHTML = links;
  $('lookupLinksArea').dataset.ma = ma; $('lookupLinksArea').dataset.token = token;
  $('lookupResultBox').hidden = false;
  $('lookupResultBox').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
};
$('lookupLinksArea').addEventListener('click', (e) => {
  const box = $('lookupLinksArea'), saved = S.auth;
  const rep = e.target.closest('[data-lookup-report]'), f = e.target.closest('[data-lookup-file]');
  if (!rep && !f) return;
  S.auth = { ma: box.dataset.ma, token: box.dataset.token };
  const p = rep ? download(`/api/export?id=${rep.dataset.lookupReport}`, { auth: true }, 'BaoCao_DVKT.xlsx')
    : download(`/api/files/${f.dataset.lookupFile}`, { auth: true }, f.dataset.name);
  p.finally(() => { S.auth = saved; });
});

// ======================= Tổng hợp quản trị =======================
async function loadSummary() {
  const pass = $('txtAdminSummaryPass').value.trim() || S.adminPass;
  if (!pass) return showDialog('warning', 'Yêu Cầu Mật Khẩu', 'Vui lòng nhập mật khẩu quản trị để xem bảng tổng hợp!');
  $('summaryContentArea').hidden = false;
  $('summaryTableContainer').innerHTML = '<div class="spinner-box"><div class="spinner"></div><div>Đang đọc dữ liệu tổng hợp...</div></div>';
  const r = await api('/api/admin/summary', { method: 'POST', body: { password: pass } });
  if (!r.success) { $('summaryContentArea').hidden = true; return showDialog('error', 'Không Thể Mở', esc(r.message)); }
  S.adminPass = pass; $('adminPasswordBox').hidden = true;
  $('countSummarySubmitted').hidden = false; $('countSummarySubmitted').textContent = r.list.length;
  S.summary = r.list; renderSummary(r.list);
}
$('btnOpenSummary').onclick = loadSummary; $('btnRefreshSummary').onclick = loadSummary;
$('txtAdminSummaryPass').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadSummary(); });
$('summaryFilter').oninput = (e) => {
  const kw = e.target.value.trim().toLowerCase();
  renderSummary(kw ? S.summary.filter((i) => i.ten.toLowerCase().includes(kw) || i.ma.toLowerCase().includes(kw)) : S.summary);
};
function renderSummary(list) {
  const box = $('summaryTableContainer');
  if (!list.length) { box.innerHTML = '<div class="center" style="padding:22px;color:#64748b">Chưa có đơn vị nào hoàn thành nộp báo cáo chính thức.</div>'; return; }
  const x = (v) => (v ? '<span class="badge-x">X</span>' : '-'), nf = (v) => (v || 0).toLocaleString('vi-VN');
  box.innerHTML = `<div class="summary-wrap"><table><thead><tr>
    <th>STT</th><th style="min-width:200px;text-align:left">Tên đơn vị</th><th>Thời gian nộp</th>
    <th title="Khám bệnh">PL1.1 Khám</th><th title="Hội chẩn ca bệnh khó">PL1.2 H.Chẩn</th><th title="Khám cấp giấy chứng thương, giám định y khoa">PL1.3 G.Định</th>
    <th title="Khám sức khỏe toàn diện lao động, lái xe, định kỳ">PL1.4 KSK.LĐ</th><th title="Khám sức khỏe cho người đi xuất khẩu lao động">PL1.5 XK.LĐ</th>
    <th>PL2</th><th>PL3</th><th>PL4</th><th>PL5</th><th>Tổng KT (PL3+PL4+PL5)</th><th>Hồ sơ / Báo cáo</th>
    <th style="min-width:180px">Nội dung yêu cầu bổ sung</th><th style="min-width:160px">Kết quả bổ sung</th><th>Mở khóa</th></tr></thead><tbody>` +
    list.map((u, i) => `<tr><td class="center"><b>${i + 1}</b></td><td><b>${esc(u.ten)}</b></td><td class="center" style="color:#64748b;font-size:11.5px">${esc(u.time)}</td>
      <td class="center">${x(u.pl1_kb)}</td><td class="center">${x(u.pl1_hc)}</td><td class="center">${x(u.pl1_gd)}</td><td class="center">${x(u.pl1_skld)}</td><td class="center">${x(u.pl1_xkd)}</td>
      <td class="center"><b style="color:#0369a1">${nf(u.c2)}</b></td><td class="center"><b style="color:#0369a1">${nf(u.c3)}</b></td><td class="center"><b style="color:#0369a1">${nf(u.c4)}</b></td><td class="center"><b style="color:#0369a1">${nf(u.c5)}</b></td>
      <td class="center" style="background:#ecfdf5"><b style="color:#059669">${nf(u.totalKT)}</b></td>
      <td class="center">${u.sheetUrl ? `<a href="${esc(u.sheetUrl)}" target="_blank" rel="noopener" style="color:#0284c7;font-weight:700;text-decoration:underline">Mở Sheet ↗</a><br>` : ''}${u.hasSnapshot ? `<a data-areport="${u.id}" style="color:#0284c7;font-weight:700;text-decoration:underline;cursor:pointer">⬇ Báo cáo</a>` :(u.folderUrl ? `<a href="${esc(u.folderUrl)}" target="_blank" rel="noopener" style="color:#0284c7;font-weight:700;text-decoration:underline">Mở Drive ↗</a>` : '-')}</td>
      <td>${u.noiDungYeuCauBoSung ? `<span class="badge-bosung-req">${esc(u.noiDungYeuCauBoSung)}</span>` : '-'}</td>
      <td>${u.ketQuaBoSung ? `<span class="badge-bosung-res">${esc(u.ketQuaBoSung)}</span>` : '-'}</td>
      <td class="center"><button class="btn btn-warning btn-xs" data-unlock="${esc(u.ma)}" data-name="${esc(u.ten)}">🔓 Mở khóa</button></td></tr>`).join('') + '</tbody></table></div>';
}
function unlockUnit(ma, name) {
  showDialog('confirm', 'MỞ KHÓA ĐƠN VỊ', `Mở khóa cho <strong>${esc(name)}</strong> để đơn vị chỉnh sửa và gửi lại báo cáo?`, null, async () => {
    const r = await api('/api/admin/unlock', { method: 'POST', body: { password: S.adminPass, ma } });
    if (!r.success) return showDialog('error', 'Lỗi', esc(r.message));
    await loadSummary(); loadHospitals();
    showDialog('success', 'Đã Mở Khóa', `Đơn vị <strong>${esc(name)}</strong> đã được mở khóa.`);
  });
  $('modalBtnOk').textContent = 'Mở khóa';
}

// ======================= Số thiết bị kết nối =======================
const clientId = Math.random().toString(36).slice(2) + Date.now().toString(36);
async function heartbeat() {
  try {
    const { count } = await api('/api/presence', { method: 'POST', body: { id: clientId } });
    $('countActiveConnections').textContent = count;
    const b = $('badgeActiveConnections'), d = $('dotConnectionStatus');
    const tone = count <= 50 ? ['#ecfdf5', '#a7f3d0', '#065f46', '#10b981'] : count <= 70 ? ['#fefce8', '#fef08a', '#854d0e', '#eab308'] : count <= 90 ? ['#fff7ed', '#fed7aa', '#9a3412', '#f97316'] : ['#fef2f2', '#fecaca', '#991b1b', '#ef4444'];
    b.style.background = tone[0]; b.style.borderColor = tone[1]; b.style.color = tone[2]; d.style.background = tone[3];
  } catch { /* bỏ qua */ }
}

// ======================= Khởi động =======================
(async function init() {
  S.cfg = await api('/api/config');
  document.title = S.cfg.title || document.title;
  loadHospitals(); heartbeat(); setInterval(heartbeat, 30000);
  await ensureHeaders();
})();
window.addEventListener('beforeunload', (e) => { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });
