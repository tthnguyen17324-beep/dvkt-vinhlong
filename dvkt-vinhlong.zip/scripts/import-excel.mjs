// Chuyển dữ liệu từ file Excel nguồn (DVKT2_DANG CHAY.xlsx) sang SQLite.
// Dùng: node scripts/import-excel.mjs "<đường dẫn file.xlsx>"
import ExcelJS from 'exceljs';
import { openDb, tx, hashToken } from '../server/db.mjs';

const file = process.argv[2];
if (!file) {
  console.error('Thiếu đường dẫn file Excel.');
  process.exit(1);
}

const WANTED = new Set([
  'DM_PL1', 'DM_PL2', 'DM_PL3_BV', 'DM_PL3_TYT', 'DM_PL4', 'DM_PL5',
  'Danh_sach_don_vi', 'Cac_lan_gui',
]);

function plain(v) {
  if (v == null) return '';
  if (v instanceof Date) return v;
  if (typeof v === 'object') {
    if ('result' in v) return plain(v.result);
    if (v.richText) return v.richText.map((t) => t.text).join('');
    if ('text' in v) return v.text;
    if ('error' in v) return '';
    return '';
  }
  return v;
}

// Số serial Excel (giờ Việt Nam, UTC+7) -> mili giây
function serialToMs(n) {
  return Math.round((n - 25569) * 86400000) - 7 * 3600000;
}

async function readSheets() {
  const wb = new ExcelJS.stream.xlsx.WorkbookReader(file, {
    sharedStrings: 'cache', worksheets: 'emit', styles: 'ignore', hyperlinks: 'ignore',
  });
  const out = {};
  for await (const ws of wb) {
    if (!WANTED.has(ws.name)) { for await (const _ of ws) { /* bỏ qua */ } continue; }
    const rows = [];
    for await (const row of ws) {
      const vals = row.values.slice(1).map(plain);
      rows[row.number - 1] = vals;
    }
    out[ws.name] = rows;
  }
  return out;
}

const str = (v) => (v == null ? '' : String(v));
const fill = (arr, n) => Array.from({ length: n }, (_, i) => (arr[i] === undefined || arr[i] === null ? '' : arr[i]));

const sheets = await readSheets();
const db = openDb();

tx(db, () => {
  for (const t of ['catalog', 'units', 'submissions']) db.exec(`DELETE FROM ${t}`);

  // ---- Danh mục ----
  const insCat = db.prepare(
    'INSERT INTO catalog (kind, seq, chuong, ma_chung, ma_kt, lh, row_json) VALUES (?,?,?,?,?,?,?)',
  );
  const catCount = {};
  for (const [sheet, kind] of [
    ['DM_PL1', 'pl1'], ['DM_PL2', 'pl2'], ['DM_PL3_BV', 'pl3_bv'],
    ['DM_PL3_TYT', 'pl3_tyt'], ['DM_PL4', 'pl4'], ['DM_PL5', 'pl5'],
  ]) {
    const rows = sheets[sheet] || [];
    const width = (rows[0] || []).length;
    let seq = 0;
    for (let i = 2; i < rows.length; i++) { // dữ liệu từ dòng 3, như bản cũ
      const r = rows[i];
      if (!r) continue;
      const row = fill(r, width);
      const chuong = kind.startsWith('pl3') || kind === 'pl4' || kind === 'pl5' ? str(row[2]).trim() : '';
      const lh = kind === 'pl1' ? str(row[13]).trim().toUpperCase()
        : kind === 'pl2' ? str(row[width - 1]).trim().toUpperCase() : '';
      insCat.run(kind, seq++, chuong, str(row[1]).trim(), kind === 'pl5' ? '' : str(row[3]).trim(), lh, JSON.stringify(row));
    }
    catCount[kind] = seq;
  }
  console.log('Danh mục:', catCount);

  // ---- Đơn vị ----
  const insUnit = db.prepare(
    'INSERT OR REPLACE INTO units (ma, ten, email, token_hash, noi_dung_bo_sung, ket_qua_bo_sung) VALUES (?,?,?,?,?,?)',
  );
  let nUnits = 0;
  const dv = sheets['Danh_sach_don_vi'] || [];
  for (let i = 1; i < dv.length; i++) {
    const r = dv[i];
    if (!r) continue;
    const ma = str(r[0]).trim().toUpperCase();
    if (!ma) continue;
    const token = str(r[3]).trim();
    insUnit.run(ma, str(r[1]).trim() || ma, str(r[10]).trim(), token ? hashToken(token) : '', str(r[12]).trim(), str(r[13]).trim());
    nUnits++;
  }
  console.log('Đơn vị:', nUnits);

  // ---- Lịch sử các lần gửi ----
  const insSub = db.prepare(`INSERT INTO submissions
    (ts, ma, ten, ho_ten, khoa_phong, chuc_vu, sdt, email, status, pl1_kb, pl1_hc, pl1_gd, pl1_skld, pl1_xkd,
     c2, c3, c4, c5, total_kt, legacy_folder_url, cpql_url) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  let nSub = 0;
  const lg = sheets['Cac_lan_gui'] || [];
  for (let i = 1; i < lg.length; i++) {
    const r = lg[i];
    if (!r) continue;
    const ma = str(r[1]).trim().toUpperCase();
    if (!ma) continue;
    let ts = 0;
    if (r[0] instanceof Date) ts = r[0].getTime();
    else if (typeof r[0] === 'number') ts = serialToMs(r[0]);
    const x = (v) => (str(v).trim() ? 'X' : '');
    const n = (v) => Number(v) || 0;
    const c3 = n(r[16]), c4 = n(r[17]), c5 = n(r[18]);
    const cpql = str(r[20]).trim();
    insSub.run(ts, ma, str(r[2]).trim(), str(r[3]).trim(), str(r[4]).trim(), str(r[5]).trim(),
      str(r[6]).trim(), str(r[7]).trim(), str(r[9]).trim(), // giữ nguyên trạng thái gốc: chỉ "Đã khóa" mới là khóa
      x(r[10]), x(r[11]), x(r[12]), x(r[13]), x(r[14]),
      n(r[15]), c3, c4, c5, n(r[19]) || c3 + c4 + c5,
      str(r[8]).trim(), cpql.startsWith('http') ? cpql : '');
    nSub++;
  }
  console.log('Lần gửi (lịch sử):', nSub);
});

db.close();
console.log('Xong.');
