﻿import ExcelJS from 'exceljs';
const file = process.argv[2];
const wb = new ExcelJS.stream.xlsx.WorkbookReader(file, { sharedStrings: 'cache', worksheets: 'emit', styles: 'ignore', hyperlinks: 'ignore' });
const cell = v => { if (v == null) return ''; if (typeof v === 'object') v = v.result ?? v.text ?? (v.richText ? v.richText.map(t=>t.text).join('') : JSON.stringify(v)); return String(v).replace(/\s+/g,' ').slice(0,42); };
for await (const ws of wb) {
  let n = 0, rows = 0; const out = [];
  for await (const row of ws) {
    rows++;
    if (n < 4 && ws.name !== 'Danh_sach_don_vi' || n < 1 && ws.name === 'Danh_sach_don_vi') { out.push('  r' + row.number + ': ' + row.values.slice(1).map(cell).join(' | ')); n++; }
  }
  console.log('== ' + ws.name + ' (' + rows + ' rows)'); out.forEach(l => console.log(l));
}
