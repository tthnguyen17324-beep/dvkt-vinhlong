// Công cụ quản trị dòng lệnh.
//   node scripts/admin.mjs list-locked
//   node scripts/admin.mjs unlock MA_DON_VI
//   node scripts/admin.mjs set-token MA_DON_VI TOKEN_MOI
//   node scripts/admin.mjs backup  (sao lưu CSDL ra thư mục data/backup)
import { openDb, hashToken, DATA_DIR } from '../server/db.mjs';
import { mkdirSync, cpSync } from 'node:fs';
import { join } from 'node:path';

const [cmd, ma, token] = process.argv.slice(2);
const db = openDb();
const MA = String(ma || '').trim().toUpperCase();

switch (cmd) {
  case 'list-locked': {
    const rows = db.prepare(`SELECT u.ma, u.ten FROM units u JOIN submissions s ON s.id =
      (SELECT id FROM submissions WHERE ma = u.ma ORDER BY ts DESC, id DESC LIMIT 1) WHERE lower(trim(s.status)) = 'đã khóa' ORDER BY u.ma`).all();
    rows.forEach((r) => console.log(`${r.ma}\t${r.ten}`));
    console.log(`Tổng: ${rows.length} đơn vị đang khóa`);
    break;
  }
  case 'unlock': {
    const s = db.prepare('SELECT id FROM submissions WHERE ma = ? ORDER BY ts DESC, id DESC LIMIT 1').get(MA);
    if (!s) { console.error('Không tìm thấy phiên nộp của đơn vị', MA); process.exit(1); }
    db.prepare("UPDATE submissions SET status = 'Đang mở khóa' WHERE id = ?").run(s.id);
    console.log('Đã mở khóa', MA);
    break;
  }
  case 'set-token': {
    if (!token || token.length < 6) { console.error('Token tối thiểu 6 ký tự'); process.exit(1); }
    const r = db.prepare('UPDATE units SET token_hash = ? WHERE ma = ?').run(hashToken(token), MA);
    console.log(r.changes ? `Đã đặt Token mới cho ${MA}` : `Không tìm thấy đơn vị ${MA}`);
    break;
  }
  case 'backup': {
    const dir = join(DATA_DIR, 'backup'); mkdirSync(dir, { recursive: true });
    const name = join(dir, `dvkt-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.db`);
    db.exec(`VACUUM INTO '${name.replace(/'/g, "''")}'`);
    console.log('Đã sao lưu:', name);
    break;
  }
  default:
    console.log('Lệnh: list-locked | unlock MA | set-token MA TOKEN | backup');
}
db.close();
